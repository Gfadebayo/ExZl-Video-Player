package com.exzell.notes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.exzell.notes.models.NoteInfo;
import com.exzell.notes.models.NoteManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class NoteListActivity extends AppCompatActivity {
    private NoteRecyclerAdapter noteRecyclerAdapter;
    private RecyclerView recyclerView;
    private TextView noNotes;

//    private List<NoteInfo> noteInfos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
      setSupportActionBar(toolbar);

      List<NoteInfo> notes = NoteManager.getInstance().getNotes();
        noNotes = findViewById(R.id.no_note_text);
        recyclerView = findViewById(R.id.notes_list);

        populateListView();

        if(notes.isEmpty()){

            noNotes.setVisibility(View.VISIBLE);
        }else recyclerView.setVisibility(View.VISIBLE);


        FloatingActionButton fab = findViewById(R.id.new_note_fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent newIntent = new Intent(NoteListActivity.this, NoteActivity.class);
                startActivity(newIntent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        noteRecyclerAdapter.notifyDataSetChanged();
    }

    private void populateListView() {

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        List<NoteInfo> notes = NoteManager.getInstance().getNotes();
        noteRecyclerAdapter = new NoteRecyclerAdapter(this, notes);
        recyclerView.setAdapter(noteRecyclerAdapter);
    }


}
