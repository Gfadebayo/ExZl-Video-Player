package com.exzell.notes;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.exzell.notes.models.NoteInfo;
import com.exzell.notes.models.NoteManager;

public class NoteActivity extends AppCompatActivity {

    public static final int NOTE_POSITION_NOT_FOUND = -1;
    private TextView textTitle;
    private EditText textContent;
    public static final String NOTE_POSITION = "com.exzell.notes.NOTE_POSITION";
    private boolean isNewNote;
    private NoteInfo noteInfo;
    private int notePosition;
    private TextView mCurrentTitle;
    private EditText mCurrentContent;
    private boolean mCancelling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textTitle = findViewById(R.id.note_title);
        textContent = findViewById(R.id.note_content);

        getListItem();
    }


    private void getListItem() {
        Intent intent = getIntent();

        notePosition = intent.getIntExtra(NOTE_POSITION, NOTE_POSITION_NOT_FOUND);

        isNewNote = notePosition == NOTE_POSITION_NOT_FOUND;

        if(isNewNote){

            notePosition = NoteManager.getInstance().createNote();

        }

        noteInfo = NoteManager.getInstance().getNotes().get(notePosition);
        textTitle.setText(noteInfo.getTitle());
        textContent.setText(noteInfo.getContent());

//        mCurrentContent = textContent;
//        mCurrentTitle = textTitle;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.items_menu, menu);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == R.id.save_option){

            finish();
            return true;
        }else if(id == R.id.cancel_option){
            mCancelling = true;
            cancelNote();
            finish();

        }else if(id == R.id.action_next){
            showNextNote();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        MenuItem item = menu.findItem(R.id.action_next);
        int lastIndex = NoteManager.getInstance().getNotes().size() - 1;

        item.setEnabled(notePosition < lastIndex);

        return super.onPrepareOptionsMenu(menu);
    }

    private void showNextNote() {

        notePosition++;

        NoteInfo nextNote = NoteManager.getInstance().getNotes().get(notePosition);

        textTitle.setText(nextNote.getTitle());
        textTitle.setText(nextNote.getContent());

        invalidateOptionsMenu();
    }

    private void cancelNote() {
        NoteManager noteManager = NoteManager.getInstance();
        if(isNewNote){
            noteManager.deleteNote(notePosition);
        }else{

           // textTitle = mCurrentTitle;
           // textContent = mCurrentContent;

            noteManager.deleteNote(notePosition);
        }

    }

    private void saveNote() {

        NoteManager manage = NoteManager.getInstance();

            NoteInfo newNote = manage.getNotes().get(notePosition);
            newNote.setNoteTitle(textTitle.getText().toString());
            newNote.setNoteContent(textContent.getText().toString());
            manage.getNotes().set(notePosition, newNote);

    }

    @Override
    protected void onPause() {
        super.onPause();

        if(mCancelling){
            cancelNote();
        }else saveNote();
    }
}
