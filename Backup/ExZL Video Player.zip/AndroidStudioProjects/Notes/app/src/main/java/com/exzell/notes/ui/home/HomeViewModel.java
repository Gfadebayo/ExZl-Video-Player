package com.exzell.notes.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.exzell.notes.models.NoteInfo;
import com.exzell.notes.models.NoteManager;

import java.util.List;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<String> mText;
    private MutableLiveData<List<NoteInfo>> mNotes;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }

    public MutableLiveData<List<NoteInfo>> getNotesData(){
        List<NoteInfo> notes = NoteManager.getInstance().getNotes();
        mNotes = new MutableLiveData<>();
        mNotes.postValue(notes);

        return  mNotes;
    }
}