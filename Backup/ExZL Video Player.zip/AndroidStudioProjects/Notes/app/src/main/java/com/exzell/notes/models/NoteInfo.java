package com.exzell.notes.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.time.LocalDateTime;

public class NoteInfo implements Parcelable {

    private String noteTitle;
    private String noteContent;
    private LocalDateTime noteTime;


    public NoteInfo(String noteTitle, String noteContent, LocalDateTime noteTime) {

        this(noteTitle, noteContent);
        //setNoteTime(noteTime);
    }
    public NoteInfo(String noteTitle, String noteContent){

        setNoteTitle(noteTitle);
        setNoteContent(noteContent);
    }

    public String getTitle(){ return noteTitle;}

    public String getContent(){return noteContent;}

    public void setNoteTitle(String title){
        noteTitle = title;
    }

    public void setNoteContent(String content){
        noteContent = content;
    }

   /* public LocalDateTime getNoteTime() {
        return noteTime;
    } */

    public void setNoteTime(LocalDateTime noteTime) {
        this.noteTime = noteTime;
    }

    @Override
    public String toString() {

        String returnString = getTitle() + "\n" + getContent();
        return returnString;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {


    }

    public static final Parcelable.Creator<NoteInfo> CREATOR = new Creator<NoteInfo>() {
        @Override
        public NoteInfo createFromParcel(Parcel source) {
            return null;
        }

        @Override
        public NoteInfo[] newArray(int size) {
            return new NoteInfo[size];
        }
    };
}
