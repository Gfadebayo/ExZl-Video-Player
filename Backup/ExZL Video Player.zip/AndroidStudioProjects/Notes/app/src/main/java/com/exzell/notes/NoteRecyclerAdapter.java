package com.exzell.notes;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.exzell.notes.models.NoteInfo;

import java.util.List;

public class NoteRecyclerAdapter extends RecyclerView.Adapter<NoteRecyclerAdapter.ViewHolder> {

    private final Context context;
    private final LayoutInflater layoutInflater;
    private final List<NoteInfo> noteList;

    public NoteRecyclerAdapter(Context context, List<NoteInfo> noteList) {
        this.context = context;
        this.noteList = noteList;
        layoutInflater = LayoutInflater.from(this.context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = layoutInflater.inflate(R.layout.note_list_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NoteInfo holdNote = noteList.get(position);
        holder.textTitle.setText(holdNote.getTitle());
        holder.textContent.setText(holdNote.getContent());
        holder.currentNotePosition = position;
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{


        public final TextView textTitle;
        public final TextView textContent;
        public int currentNotePosition;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textTitle = itemView.findViewById(R.id.note_list_title);
            textContent = itemView.findViewById(R.id.note_list_content);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, NoteActivity.class);
                    intent.putExtra(NoteActivity.NOTE_POSITION, currentNotePosition);
                    context.startActivity(intent);
                }
            });
        }
    }
}
