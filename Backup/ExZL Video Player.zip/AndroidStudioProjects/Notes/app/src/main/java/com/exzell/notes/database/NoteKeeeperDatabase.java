package com.exzell.notes.database;

import android.provider.BaseColumns;

public final class NoteKeeeperDatabase {

    public NoteKeeeperDatabase(){}

    public final class NotesTable implements BaseColumns {

        public static final String TABLE_NAME = "notes_info";
        public static final String COLUMN_NOTE_TITLE = "note_title";
        public static final String COLUMN_NOTE_CONTENT = "note_content";

        public static final String SQL_CREATE_TABLE = "CREATE TABLE " +TABLE_NAME +
                " (" + _ID + " INTEGER PRIMARY KEY, " + COLUMN_NOTE_TITLE + " TEXT, " + COLUMN_NOTE_CONTENT + " TEXT NOT NULL)";

    }
}
