package com.exzell.notes;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.exzell.notes.database.NoteKeeperHelper;
import com.exzell.notes.ui.gallery.GalleryFragment;
import com.exzell.notes.ui.home.HomeFragment;
import com.exzell.notes.ui.tools.ToolsFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.webkit.WebView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    private NoteRecyclerAdapter noteRecyclerAdapter;
    private RecyclerView recyclerView;
    private TextView noNotes;
    private NoteKeeperHelper notedb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        notedb = new NoteKeeperHelper(this);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newIntent = new Intent(MainActivity.this, NoteActivity.class);
                startActivity(newIntent);
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        mAppBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).setDrawerLayout(drawer).build();
//        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        NavigationUI.setupWithNavController(toolbar, navController, mAppBarConfiguration);

        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {

                changeNavigationDestination(destination.getId());

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        int id = item.getItemId();

        if(id == R.id.action_settings){

            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }
        return NavigationUI.onNavDestinationSelected(item, navController)|| super.onOptionsItemSelected(item);
    }

    public void changeNavigationDestination(int destinationID){
        Fragment fragment = null;
        Bundle bundle = new Bundle();

        if(destinationID == R.id.nav_home){
            fragment = new HomeFragment();
            SQLiteDatabase db = notedb.getReadableDatabase();
            //Snackbar.make(findViewById(R.id.notes_list), "Home Home Home", Snackbar.LENGTH_LONG);
        }else if(destinationID == R.id.nav_gallery){
            fragment = new GalleryFragment();
            Snackbar.make(findViewById(R.id.text_send), "Gallery", Snackbar.LENGTH_LONG);
        }else if(destinationID == R.id.nav_tools){
            fragment = new ToolsFragment();
        }else if(destinationID == R.id.nav_mal){
            bundle.putString("url", "http://myanimelist.net");
//                    fragment = new WebView();
        }else if(destinationID == R.id.nav_manga_updates){
            bundle.putString("url", "http://mangaupdates.com");

        }
        if(fragment != null){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, fragment).commit();
        }

    }

    @Override
    protected void onDestroy() {
        notedb.close();
        super.onDestroy();
    }

    /*@Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
*/


}
