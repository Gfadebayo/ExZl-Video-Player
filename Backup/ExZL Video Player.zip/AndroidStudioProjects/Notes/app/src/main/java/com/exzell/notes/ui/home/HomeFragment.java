package com.exzell.notes.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.exzell.notes.models.NoteInfo;
import com.exzell.notes.models.NoteManager;
import com.exzell.notes.NoteRecyclerAdapter;
import com.exzell.notes.R;

import java.util.List;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private RecyclerView recyclerView;
//    private TextView noNotes;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = root.findViewById(R.id.notes_list);

        homeViewModel.getNotesData().observe(this, new Observer<List<NoteInfo>>() {
            @Override
            public void onChanged(List<NoteInfo> noteInfos) {
                NoteRecyclerAdapter noteRecyclerAdapter = new NoteRecyclerAdapter(getContext(), noteInfos);

                recyclerView.setAdapter(noteRecyclerAdapter);
            }
        });
        return root;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        createViews();
//    }

    /*public void createViews(){

        List<NoteInfo> notes = NoteManager.getInstance().getNotes();

       // populateListView();

        if(notes.isEmpty()){

            noNotes.setVisibility(View.VISIBLE);
        }else recyclerView.setVisibility(View.VISIBLE);

    }*/

    @Override
    public void onResume() {
        super.onResume();

//        noteRecyclerAdapter.notifyDataSetChanged();

    }

   /* private void populateListView() {

        LinearLayoutManager layoutManager = new LinearLayoutManager();
        recyclerView.setLayoutManager(layoutManager);

        List<NoteInfo> notes = NoteManager.getInstance().getNotes();
        noteRecyclerAdapter = new NoteRecyclerAdapter(getView().getContext(), notes);
        recyclerView.setAdapter(noteRecyclerAdapter);
    }*/
}