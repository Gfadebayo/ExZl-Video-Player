package com.exzell.notes.models;

import android.database.sqlite.SQLiteOpenHelper;

import com.exzell.notes.database.NoteKeeperHelper;

import java.util.ArrayList;
import java.util.List;

public class NoteManager {

    private static NoteManager noteInstance;
    private static List<NoteInfo> notes;
    public NoteInfo currentNote;
    private NoteKeeperHelper dbHelper;

    private  NoteManager() {
       notes = new ArrayList<>();
    }

    public static NoteManager getInstance(){

        if(noteInstance == null){ noteInstance = new NoteManager();}
        return noteInstance;
    }


    public int createNote(){
        //LocalDateTime localDateTime =
        int noteCurrentSize = notes.size();
        NoteInfo noteInfo = new NoteInfo(null, null);

//        NoteInfo noteInfo = new NoteInfo(title, content, localDateTime);

            notes.add(noteCurrentSize, noteInfo);
            return noteCurrentSize;
    }

    public void deleteNote(int notePosition){

        if(notes.isEmpty()) return;

        notes.remove(notePosition);
    }

    public boolean getNote(int notePosition){

        if(!notes.isEmpty()){
            currentNote = notes.get(notePosition);
            return true;
        }
        else return false;
    }

    public List<NoteInfo> getNotes(){

        return notes;
    }
}
