package com.exzell.exzlvideoplayer.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

import com.exzell.exzlvideoplayer.MediaFile;

import java.util.List;

public class SuggestionAdapter extends CursorAdapter {


    public SuggestionAdapter(Context context, List<MediaFile> allFiles){
        this(context, null, 2);


    }
    public SuggestionAdapter(Context context, Cursor c, int flags) {
        super(context, c, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return null;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

    }


}
