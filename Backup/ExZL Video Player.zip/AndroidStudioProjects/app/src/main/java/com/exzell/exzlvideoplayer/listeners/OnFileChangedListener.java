package com.exzell.exzlvideoplayer.listeners;

import android.net.Uri;

public interface OnFileChangedListener {

    void onFileChanged(String changedFile);
}
