package com.exzell.exzlvideoplayer.listeners;

import android.view.View;

public interface OnFileHighlightListener {
    void onFileHighlight(View v, boolean toAdd);
}
