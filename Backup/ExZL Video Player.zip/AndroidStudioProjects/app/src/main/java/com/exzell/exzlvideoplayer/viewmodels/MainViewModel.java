package com.exzell.exzlvideoplayer.viewmodels;

import android.app.Application;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;


import com.exzell.exzlvideoplayer.MediaFile;
import com.exzell.exzlvideoplayer.adapter.VideoFileAdapter;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

public class MainViewModel extends AndroidViewModel {

    private final String TAG = getClass().getSimpleName();
    private MutableLiveData<MediaFile.Sort> sortOrder;
    private MutableLiveData<Boolean> isAscending;
    private LinkedList<VideoFileAdapter> usedVideoAdapters = new LinkedList<>();
    private LinkedList<VideoFileAdapter> usedAudioAdapters = new LinkedList<>();
    private LinkedList<String> mSelectedFiles = new LinkedList<>();


    public MainViewModel(@NonNull Application application) {
        super(application);
    }


    public LiveData<MediaFile.Sort> getSortOrder(){
        if(sortOrder == null){
            sortOrder = new MutableLiveData<>();
            sortOrder.postValue(MediaFile.Sort.NAME);
            sortOrder.setValue(MediaFile.Sort.NAME);
        }
        return sortOrder;
    }

    public List<Bundle> cursorQuery(ContentResolver cr, Uri queriedUri, String selection, String key, String sortOrder, String... columnsToBeSelected){
        Cursor query = null;
        List<Bundle> resultBundle = new ArrayList<>();

        try {
            query = cr.query(queriedUri, columnsToBeSelected, selection, null, sortOrder);
        }catch(Exception n){
            Log.d(key, "Failed to query uri");
        }
        if(query == null) return resultBundle;

        while(query.moveToNext()) {
            Bundle bund = new Bundle(columnsToBeSelected.length);

            for(int i = 0; i < columnsToBeSelected.length; i++){
                //since the column type may not be known
                //it is better to get it ourselves
                switch (query.getType(i)){
                    case Cursor.FIELD_TYPE_STRING:
                        bund.putString(columnsToBeSelected[i], query.getString(i));
                        break;
                    case Cursor.FIELD_TYPE_INTEGER:
                        bund.putInt(columnsToBeSelected[i], query.getInt(i));
                        break;
                    case Cursor.FIELD_TYPE_FLOAT:
                        bund.putFloat(columnsToBeSelected[i], query.getFloat(i));
                        break;
                }
            }

            resultBundle.add(bund);
        }

        query.close();

        return resultBundle;
    }

    public LiveData<Boolean> isAscending(){
        if(isAscending == null) {
            isAscending = new MutableLiveData<>();
            isAscending.postValue(Boolean.TRUE);
            isAscending.setValue(Boolean.TRUE);
        }
        return isAscending;
    }

    public LinkedList<String> getSelectedFiles(){
        return mSelectedFiles;
    }

    public void setSortOrder(MediaFile.Sort newOrder){
        sortOrder.postValue(newOrder);
        sortOrder.setValue(newOrder);
    }

    public void setAscending(boolean ascend){
        isAscending.postValue(ascend);
        isAscending.setValue(ascend);
    }

    public VideoFileAdapter getCurrentAdapter(boolean which){
        VideoFileAdapter currentAdapters;
        if(which) currentAdapters = usedVideoAdapters.pollFirst();
        else currentAdapters = usedAudioAdapters.pollFirst();
//        if(currentAdapters == null) {
//            currentAdapters = new ArrayList<>();
//            currentAdapters.add(null);
//        }
        if(currentAdapters != null) return currentAdapters;
        else return null;
    }

    public void setCurrentAdapter(VideoFileAdapter adapter, boolean which){

        //a size of 2 means both the audio and video adapters have been set so ceating a new array is the solution
        if(which) {
            usedVideoAdapters.offerFirst(adapter);
        } else {
            usedAudioAdapters.offerFirst(adapter);
        }
    }

    public int usedAdaptersSize(boolean which){
        if(which) return usedVideoAdapters.size();
        else return usedAudioAdapters.size();
    }
}
