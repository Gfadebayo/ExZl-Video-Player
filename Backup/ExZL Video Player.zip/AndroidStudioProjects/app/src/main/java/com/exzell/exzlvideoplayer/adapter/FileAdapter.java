package com.exzell.exzlvideoplayer.adapter;

import android.content.Context;
import android.database.DataSetObserver;
import android.os.FileObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.exzell.exzlvideoplayer.R;
import com.exzell.exzlvideoplayer.MediaUtils;

import java.util.List;

public class FileAdapter implements ListAdapter {
    private LayoutInflater mInflater;
    private List<MediaUtils> mVideoFileInformations;
    private String fileName;

    public FileAdapter(Context context, List<MediaUtils> files){
        mInflater = LayoutInflater.from(context);
        mVideoFileInformations = files;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public int getCount() {
        if(mVideoFileInformations == null) return 0;
        return mVideoFileInformations.size();
    }

    @Override
    public Object getItem(int position) {
        return mVideoFileInformations.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null)
            convertView = mInflater.inflate(R.layout.list_view_items, parent, false);

        inflateViews(mVideoFileInformations.get(position), convertView);

        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        if(mVideoFileInformations.isEmpty()) return true;

        return false;
    }

    private void inflateViews(MediaUtils fileInfo, View view){
//        ((ImageView) view.findViewById(R.id.image_thumbnail)).setImageBitmap(fileInfo.getThumbNail());
        TextView tv = ((TextView) view.findViewById(R.id.text_file_name));
//        tv.setText(fileInfo.getFileName());
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }
}
