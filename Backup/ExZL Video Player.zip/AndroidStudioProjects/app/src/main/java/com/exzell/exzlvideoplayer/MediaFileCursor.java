package com.exzell.exzlvideoplayer;

import android.database.AbstractCursor;
import android.provider.BaseColumns;

import java.util.List;

public class MediaFileCursor extends AbstractCursor {


    List<MediaFile> mFiles;
    public MediaFileCursor(List<MediaFile> files){
        mFiles = files;
    }

    @Override
    public int getCount() {
        return mFiles.size();
    }

    @Override
    public String[] getColumnNames() {
        return new String[0];
    }

    @Override
    public String getString(int column) {
        return null;
    }

    @Override
    public short getShort(int column) {
        return 0;
    }

    @Override
    public int getInt(int column) {
        return 0;
    }

    @Override
    public long getLong(int column) {
        return 0;
    }

    @Override
    public float getFloat(int column) {
        return 0;
    }

    @Override
    public double getDouble(int column) {
        return 0;
    }

    @Override
    public boolean isNull(int column) {
        return false;
    }
}
