package com.exzell.exzlvideoplayer;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.app.DownloadManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.DataSetObserver;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telephony.mbms.DownloadRequest;
import android.util.Log;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SearchEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.exzell.exzlvideoplayer.adapter.SectionsPagerAdapter;
import com.exzell.exzlvideoplayer.viewmodels.MainViewModel;
import com.google.android.material.tabs.TabLayout;

import java.io.File;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private final String TAG = this.getClass().getSimpleName();
    private SectionsPagerAdapter mAdapter;
    private ViewPager mPager;
    private MainViewModel mViewModel;
    private Thread thumbThread = new Thread(new ThumbThread());
    private boolean isThreadDone = false;
    private Intent mServiceIntent;
    private PendingIntent mResultBroadcast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Files");
        setSupportActionBar(toolbar);

        mServiceIntent = new Intent();
        mServiceIntent.setClass(this, MediaObserverService.class);
        mResultBroadcast = PendingIntent.getBroadcast(this, 2, mServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        mServiceIntent.putExtra("Emperor", mResultBroadcast);


        mViewModel = new ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication())).get(MainViewModel.class);

        if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        startDialog();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mAdapter = new SectionsPagerAdapter(MainActivity.this, getSupportFragmentManager());
                mPager = findViewById(R.id.view_pager);
                mPager.setAdapter(mAdapter);

                mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                    @Override
                    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                    }

                    @Override
                    public void onPageSelected(int position) {
                        FragmentVideos item = (FragmentVideos) mAdapter.instantiateItem(mPager, position);
                        if(item.isAdded())
                            item.onBackPressed();
                    }

                    @Override
                    public void onPageScrollStateChanged(int state) {

                    }
                });

                TabLayout tabs = findViewById(R.id.tabs);
                tabs.setupWithViewPager(mPager);


            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

    }



    private void startDialog(){

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                thumbThread.start();

                AlertDialog dia = new AlertDialog.Builder(MainActivity.this)
                        .setView(R.layout.thumbnail_dialog)
                        .setCancelable(false)
                        .create();

                dia.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(final DialogInterface dialog) {

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                while (true){
                                    if(isThreadDone){
                                        dialog.cancel();
                                        startService(mServiceIntent);
                                        break;
                                    }
                                }
                            }
                        }).start();
                    }
                });
                dia.show();
                dia.setContentView(R.layout.thumbnail_dialog);
            }
        });
    }

    public void getFileName(View view) {
        int currentItem = mPager.getCurrentItem();
        FragmentVideos vid = (FragmentVideos) mAdapter.instantiateItem(mPager, currentItem);

        ImageView childImage = findViewById(R.id.image_thumbnail);

        ColorDrawable alpha = (ColorDrawable) ((ConstraintLayout) ((View) childImage.getParent()).getParent()).getBackground();

        boolean ok = alpha.getColor() == getColor(R.color.colorAccent);

        if(!ok) {
            try {
                vid.getFileName(view);
            } catch (Exception e) {
                e.printStackTrace();
                Log.d(TAG, "Failed again");
            }
        }else{
            vid.changeFolderState(view);
        }
    }

    @Override
    public void onBackPressed() {
        FragmentVideos vids = (FragmentVideos) mAdapter.instantiateItem(mPager, mPager.getCurrentItem());
        if(vids.initPreviousAdapter() == null) finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(mServiceIntent);
    }

    private class ThumbThread implements Runnable{

        private List<Bundle> mediaFiles = new ArrayList<>(100);
        @Override
        public void run() {
            getFiles();
            loadThumbnails();
        }

        private void loadThumbnails(){
            for(Bundle file : mediaFiles){
                File media = new File(file.getString(MediaStore.Audio.Media.DATA));

                MediaUtils.loadThumbIntoCache(MainActivity.this.getExternalCacheDir(), media.getPath(), null);

            }

            isThreadDone = true;
        }

        private void getFiles(){
            Uri vidUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            Uri audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            String query = MediaStore.Audio.Media.DATA;

            mediaFiles.addAll(mViewModel.cursorQuery(getContentResolver(), vidUri, null, "ok", query, query));
            mediaFiles.addAll(mViewModel.cursorQuery(getContentResolver(), audioUri, null, "ok", query, query));

        }
    }

}
