package com.exzell.exzlvideoplayer;

import com.exzell.exzlvideoplayer.listeners.OnFileChangedListener;

public class ObserverUtils {

    private static ObserverUtils sUtils;
    private OnFileChangedListener[] listeners = new OnFileChangedListener[2];

    public static ObserverUtils getInstance(){
        if(sUtils == null) sUtils = new ObserverUtils();
        return sUtils;
    }

    private ObserverUtils(){}

    public void setObserverListeners(OnFileChangedListener lis){
        if(listeners[0] == null) listeners[0] = lis;
        else listeners[1] = lis;
    }

    public OnFileChangedListener[] getListeners(){
        return listeners;
    }
}
