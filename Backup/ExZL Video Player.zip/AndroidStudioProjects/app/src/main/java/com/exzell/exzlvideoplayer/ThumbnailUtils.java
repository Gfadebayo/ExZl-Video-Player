package com.exzell.exzlvideoplayer;

import android.os.Handler;
import android.provider.MediaStore;
import android.widget.NumberPicker;

import java.io.File;

public class ThumbnailUtils {
    private String thumbnailDir;
    private static ThumbnailUtils sThumb;

    public static ThumbnailUtils getUtils(){
        if(sThumb == null) sThumb = new ThumbnailUtils();
        return sThumb;
    }

    private ThumbnailUtils(){}

    public String getThumbnailDir(){return thumbnailDir;}

    public void setThumbnailDir(String dir){thumbnailDir = dir;}

    public void removeThumbnail(Handler hand){

        hand.postDelayed(new Runnable() {
            @Override
            public void run() {
                File f = new File(thumbnailDir);
                if(!f.exists()) return;
                MediaUtils.deleteFile(null, thumbnailDir);
                thumbnailDir = null;
            }
        }, 60000);
    }

    private class ThumbnailKeeper implements Runnable{

        @Override
        public void run() {
            try {
                File f = new File(thumbnailDir);
                if (thumbnailDir == null || !f.exists()) Thread.currentThread().interrupt();
                else Thread.sleep(60000);
            }catch(InterruptedException ie){
                Thread.currentThread().interrupt();
                ie.printStackTrace();}

        }
    }
}
