package com.exzell.exzlvideoplayer;

import android.app.DownloadManager;
import android.net.Uri;
import android.webkit.WebView;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class InternetUtils {

    public static void openLink(String link){

        try {
            URL url = new URL(link);
            HttpURLConnection http =  (HttpURLConnection) url.openConnection();

            InputStream downStream = new BufferedInputStream(http.getInputStream());
            downStream.close();
        }catch(IOException me){me.printStackTrace(); }

        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(link));

    }
}
