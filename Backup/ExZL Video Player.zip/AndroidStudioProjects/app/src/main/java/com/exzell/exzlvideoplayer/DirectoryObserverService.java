package com.exzell.exzlvideoplayer;

import android.app.IntentService;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.Intent;
import android.database.ContentObserver;
import android.os.Environment;
import android.os.FileObserver;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.exzell.exzlvideoplayer.listeners.OnFileChangedListener;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class DirectoryObserverService extends IntentService {

    private final String TAG = this.getClass().getSimpleName();
    private DirectoryObserver observe;
    private PendingIntent result;



    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */
    public DirectoryObserverService(String name) {
        super("Watcher");

    }

    public DirectoryObserverService(){
        super("ok");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Toast.makeText(this, "Service started", Toast.LENGTH_SHORT).show();
        String internal;


        String parent = this.getExternalCacheDir().getParent();
        String[] split = parent.split("/");
        //position 0 is an empty space

        internal = "/" + split[1] + "/";
        observe = new DirectoryObserver(Environment.getExternalStorageDirectory().getPath());
        observe.startWatching();

    }


    private class DirectoryObserver extends FileObserver{

        private List<SingleFileObserver> mFileObservers;
        private String mPath;
        private int mMask;
        private Handler mHand;
        private OnFileChangedListener[] changedFile;




        public DirectoryObserver(String path) {
            this(path, FileObserver.ALL_EVENTS);
        }

        public DirectoryObserver(String path, int mask) {
            super(path, mask);
            mPath = path;
            mMask = mask;
            mHand = new Handler(getMainLooper());
//            changedFile = MediaUtils.getInstance().onChanged;

        }

        @Override
        public void startWatching() {
            Log.i(TAG, "Watching started");
            if(mFileObservers != null) return;

            mFileObservers = new ArrayList<>();
            Stack<String> stack = new Stack<>();
            stack.push(mPath);

            File file;
            String childPath;
            File[] files;

            while(!stack.isEmpty()){
                childPath = stack.pop();
                mFileObservers.add(new SingleFileObserver(childPath, mMask));

                file = new File(childPath);
                files = file.listFiles();
                if(files == null) continue;

                for(File subFile : files){
                    if(subFile == null) continue;

                    if(subFile.isDirectory()
                            && subFile.exists()
                            && !subFile.getName().equals(".")
                            && !subFile.getName().equals("..")){
                        stack.push(subFile.getPath());
                    }
                }
            }

            for(SingleFileObserver ob : mFileObservers) ob.startWatching();
        }

        @Override
        public void onEvent(int event, @Nullable String path) {
            final int e = event;
            if(event == FileObserver.ACCESS) return;
            boolean involvedEvent = false;

            String toastText = "Nothing";
            switch (event){
                case FileObserver.MODIFY:
                    toastText = "File modified";
                    involvedEvent = true;
                    break;
                case FileObserver.CREATE:
                    toastText = "File Created";
                    File check = new File(path);
                    if(check.isDirectory()) addNewObserver(check.getPath());
                    else involvedEvent = true;
                    break;
                case FileObserver.MOVED_TO:
                    toastText = "File moved";
                    involvedEvent = true;
                    break;
                case FileObserver.DELETE:
                case FileObserver.DELETE_SELF:
                    toastText = "File deleted";
                    involvedEvent = true;
                    break;
            }
            final String fin = toastText;

            if(involvedEvent) {
//                changedFile[0].onFileChanged(path, event);
//                changedFile[1].onFileChanged(path, event);
            }
            if(!toastText.equals("Nothing"))
            mHand.post(new Runnable() {
                @Override
                public void run() {
                    Log.i(TAG, fin + e);
                    Toast.makeText(DirectoryObserverService.this, fin, Toast.LENGTH_LONG).show();
                }
            });

            Log.w(TAG, "Currently observing " + mFileObservers.size() + " files with event " + event);
        }

        private void addNewObserver(String path){
            SingleFileObserver newDir = new SingleFileObserver(path, mMask);
            if(mFileObservers.contains(newDir)) return;
            mFileObservers.add(newDir);
            newDir.startWatching();
        }

        @Override
        public void stopWatching() {
            Log.i(TAG, "Watching stopped");
            if(mFileObservers == null) return;

            for(SingleFileObserver ob : mFileObservers) ob.stopWatching();
            mFileObservers.clear();
            mFileObservers = null;
        }
    }

    private final class SingleFileObserver extends FileObserver{
        private String mPath;

        public SingleFileObserver(String path, int mask) {
            super(path, mask);
            mPath = path;
            Log.i(TAG, "Time to start watching " + path);
        }

        @Override
        public void onEvent(int event, @Nullable String path) {
            String finalPath = mPath + "/" + path;
            Log.i(TAG, "Event time for " + path);
            DirectoryObserverService.this.observe.onEvent(event, finalPath);
        }

        @Override
        public boolean equals(@Nullable Object obj) {
            if(!(obj instanceof SingleFileObserver)) return false;

            SingleFileObserver ob = (SingleFileObserver) obj;

            if(mPath.equals(ob.mPath)) return true;
            else return false;
        }
    }
}
