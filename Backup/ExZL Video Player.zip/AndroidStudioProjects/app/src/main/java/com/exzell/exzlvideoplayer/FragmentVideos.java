package com.exzell.exzlvideoplayer;

import android.app.SearchableInfo;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.FileObserver;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.os.HandlerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.exzell.exzlvideoplayer.adapter.VideoFileAdapter;
import com.exzell.exzlvideoplayer.listeners.OnFileChangedListener;
import com.exzell.exzlvideoplayer.viewmodels.MainViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class FragmentVideos extends Fragment implements OnFileChangedListener {

    private final String TAG = this.getClass().getSimpleName();
    private MainViewModel mViewModel;
    private Map<MediaFile, List<MediaFile>> mFileInfos;

    private RecyclerView mRecyclerView;
    private StaggeredGridLayoutManager mGridManager;
    private LinearLayoutManager mLinearManager;
    private VideoFileAdapter mAdapter;

    private ContentResolver mContentResolver;
    private boolean isForVideos;
    private ExecutorService mExecutor;


    public static FragmentVideos newInstance(int type){
        FragmentVideos vids = new FragmentVideos();
        Bundle extras = new Bundle(1);
        extras.putInt("TAB", type);
        vids.setArguments(extras);

        return vids;
    }

    private void unravelBundle(){
        Bundle args = getArguments();
        if(args == null) return;
        int decision = args.getInt("TAB");

        isForVideos = decision == R.string.video;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_videos, container, false);
//        parentPath();
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        mViewModel = new ViewModelProvider(requireActivity(),
                ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().getApplication()))
                .get(MainViewModel.class);

        mContentResolver = requireActivity().getContentResolver();

        readUsingUri();
        mRecyclerView = view.findViewById(R.id.list_file);
        mRecyclerView.setHasFixedSize(true);
        mGridManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mLinearManager = new LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, true);

        mAdapter.setHasStableIds(true);
        mRecyclerView.setAdapter(mAdapter);

        view.findViewById(R.id.fab_current_file).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean b = sendFileToPlayer(null, mViewModel.getSelectedFiles());
                if(!b) Toast.makeText(requireContext(), "Previously Selected File not Found", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        setHasOptionsMenu(true);
        mExecutor = Executors.newFixedThreadPool(6);
        MediaFile.submitThumbnailDir(requireContext().getExternalCacheDir());

        unravelBundle();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_videos, menu);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        switch (mViewModel.getSortOrder().getValue()) {
            case NAME:
                menu.findItem(R.id.action_title).setChecked(true);
                break;
            case DATE:
                menu.findItem(R.id.action_date).setChecked(true);
                break;
            case SIZE:
                menu.findItem(R.id.action_size).setChecked(true);
                break;
            case DURATION:
                menu.findItem(R.id.action_duration).setChecked(true);
                break;
        }

        menu.findItem(R.id.action_ascending).setChecked(mViewModel.isAscending().getValue());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        boolean ret = false;
        boolean restartFrag = false;
        MediaFile.Sort order = null;

        switch (itemId) {
            case R.id.action_title:
                item.setChecked(true);
                order = MediaFile.Sort.NAME;
                ret = restartFrag = true;
                break;
            case R.id.action_date:
                item.setChecked(true);
                order = MediaFile.Sort.DATE;
                ret = restartFrag = true;
                break;
            case R.id.action_size:
                item.setChecked(true);
                order = MediaFile.Sort.SIZE;
                ret = restartFrag = true;
                break;
            case R.id.action_duration:
                item.setChecked(true);
                order = MediaFile.Sort.DURATION;
                ret = restartFrag = true;
                break;
            case R.id.action_ascending:
                boolean checked = !item.isChecked();
                mViewModel.setAscending(checked);
                item.setChecked(checked);
                restartFrag = true;
                break;
            case R.id.action_layout:
                changeLayout(item);
                ret = true;
                break;
            case R.id.action_search:
                performSearch(item);
                ret = true;
                break;
        }

        if(order != null) mViewModel.setSortOrder(order);
        if(restartFrag){
            VideoFileAdapter newAdapter;

                List<MediaFile> files = mAdapter.getFiles();
                MediaUtils.sort(mViewModel.getSortOrder().getValue(), mViewModel.isAscending().getValue(), files);
                mAdapter.notifyDataSetChanged();
//                newAdapter = new VideoFileAdapter(files, requireContext(), requireActivity().findViewById(R.id.view_pager));
//
//            mRecyclerView.setAdapter(newAdapter);
//            mAdapter = newAdapter;

        }

        return ret;
    }

    private void performSearch(MenuItem item) {
        final SearchView sView = (SearchView) item.getActionView();
        sView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                return false;
            }
        });


        sView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sView.setIconified(false);
            }
        });

        sView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Log.i(TAG, "Text Entered in the search box");
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
    }

    public void getFileName(View v) {
        final VideoFileAdapter.ViewHolder holder = (VideoFileAdapter.ViewHolder) mRecyclerView.getChildViewHolder(v);
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                MediaFile checker = new MediaFile(holder.filePath);
                if (!mFileInfos.keySet().contains(checker)) {
                    String pat = holder.getPath();
                    sendFileToPlayer(pat, null);
                } else {
                    List<MediaFile> files = mFileInfos.get(checker);
                    MediaUtils.sort(mViewModel.getSortOrder().getValue(), mViewModel.isAscending().getValue(), files);
                    VideoFileAdapter newAdapter = new VideoFileAdapter(files, requireActivity(), requireActivity().findViewById(R.id.view_pager));
                    mViewModel.setCurrentAdapter(mAdapter, isForVideos);
                    mRecyclerView.setAdapter(newAdapter);
                    mAdapter = newAdapter;
                    ((Toolbar) requireActivity().findViewById(R.id.toolbar)).setTitle(holder.mTextName.getText().toString());
                    onBackPressed();
//            mViewModel.setCurrentAdapter(newAdapter, isForVideos);
//            ((FragmentPager) getParentFragment()).destroyAndRecreate();
                }
            }
        });

    }

    private void readUsingUri(){
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Uri volumeExternal;
                if(isForVideos) volumeExternal = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                else volumeExternal = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

                String[] requiredColumns = {MediaStore.Audio.Media.DISPLAY_NAME,
                        MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.SIZE};

                VideoFileAdapter viewModelAdapter = mViewModel.getCurrentAdapter(isForVideos);

                if(viewModelAdapter != null) mAdapter = viewModelAdapter;
                else {
                    List<Bundle> media = mViewModel.cursorQuery(mContentResolver, volumeExternal, null, TAG, MediaStore.Audio.Media.DISPLAY_NAME, requiredColumns);

                    unwrapBundleAndCreateMediaInfos(media);
                    ObserverUtils.getInstance().setObserverListeners(FragmentVideos.this);
                    mAdapter = new VideoFileAdapter(requireActivity(), mFileInfos.keySet());
                    MediaUtils.sort(mViewModel.getSortOrder().getValue(), mViewModel.isAscending().getValue(), mAdapter.getFiles());
                    mAdapter.notifyDataSetChanged();

                }

                onBackPressed();
            }
        });

    }

    private void unwrapBundleAndCreateMediaInfos(final List<Bundle> mediaFiles){
        Map<MediaFile, List<MediaFile>> parents = new HashMap<>();

        try{
            parents =
            mExecutor.submit(new Callable<Map<MediaFile, List<MediaFile>>>() {
                Map<MediaFile, List<MediaFile>> in = new HashMap<>();
                @Override
                public Map<MediaFile, List<MediaFile>> call() throws Exception {
                    String data = MediaStore.Video.Media.DATA;
                    String size = MediaStore.Video.Media.SIZE;
                    String add = MediaStore.Video.Media.DATE_ADDED;

                    for(Bundle b : mediaFiles){
                        File child = new File(b.getString(data));
                        String path = child.getParent();
                        MediaFile chi = new MediaFile(child.getPath(), b.getInt(size), b.getInt(add));
                        MediaFile parent = new MediaFile(path);

                        List<MediaFile> paren = in.get(parent);
                        if(paren == null) paren = new ArrayList<>(mediaFiles.size());
                        paren.add(chi);
                        in.put(parent, paren);
                    }
                    return in;
                }
            }).get();
        } catch (ExecutionException | InterruptedException | CancellationException e){
            e.printStackTrace();
        }

        parentFileSize(parents);
        mFileInfos = parents;
    }

    private boolean sendFileToPlayer(final String pat, final LinkedList<String> pats){
        final ArrayList<Boolean> ret = new ArrayList<>(1);
        ret.add(true);
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent play = new Intent();
                play.setClass(requireActivity(), PlaybackActivity.class);
                try {
                    if (pat != null) {
                        LinkedList<String> file = new LinkedList<>();
                        file.add(pat);
//                        mViewModel.setSelectedFile(file);
                        play.putExtra(PlaybackActivity.TAG, new ArrayList<String>(file));
                    } else if(pats != null || !pats.isEmpty()) {
//                        mViewModel.setSelectedFile(pats);
                        play.putExtra(PlaybackActivity.TAG, new ArrayList<String>(pats));
                    }else{
                        ret.set(0, false);
                    }
//                    mViewModel.setCurrentAdapter(mAdapter, isForVideos);
                    if(ret.get(0)) startActivity(play);
                }catch(Exception e){
                    Toast.makeText(requireContext(), "No Previously Selected File", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return ret.get(0);
    }

    public void selectFiles(String path, boolean toAdd){

        if(toAdd) {
            mViewModel.getSelectedFiles().offerLast(path);
            fabWiggle();
        } else mViewModel.getSelectedFiles().remove(path);
    }

    public void onBackPressed(){
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int adaptersSize = mViewModel.usedAdaptersSize(isForVideos);
                if(adaptersSize >= 1){
                    Toolbar bar = requireActivity().findViewById(R.id.toolbar);
                    bar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
                    bar.setNavigationOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initPreviousAdapter();
                        }
                    });
                }else{
                    Toolbar bar = requireActivity().findViewById(R.id.toolbar);
                    bar.setNavigationIcon(null);
                    bar.setTitle(R.string.files);
//                    NavigationUI.setupWithNavController(bar, Navigation.findNavController(requireActivity(), R.id.nav_host_fragment));
                }
            }
        });

    }

    public void changeFolderState(final View view) {
        VideoFileAdapter.ViewHolder holder = (VideoFileAdapter.ViewHolder) mRecyclerView.getChildViewHolder(view);
        holder.selectFile();
    }

    public VideoFileAdapter initPreviousAdapter(){
        VideoFileAdapter currentAdapter = mViewModel.getCurrentAdapter(isForVideos);
        if(currentAdapter == null) return null;

        mRecyclerView.setAdapter(currentAdapter);
        mAdapter = currentAdapter;

        ViewPager page = requireActivity().findViewById(R.id.view_pager);
        page.getAdapter().notifyDataSetChanged();
        onBackPressed();

        return currentAdapter;

    }

    public void fabWiggle(){
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                FloatingActionButton fab = requireActivity().findViewById(R.id.fab_current_file);
                final float alp = 50;


                final ViewPropertyAnimator animate = fab.animate();

                AccelerateDecelerateInterpolator inter = (AccelerateDecelerateInterpolator) animate.getInterpolator();
                animate.setDuration(1000)
                        .translationZBy(alp)
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                animate.translationZ(0).setDuration(1000).start();
                            }
                        })
                        .start();
            }
        });
    }

    private void changeLayout(final MenuItem item){

        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String title = item.getTitle().toString();

                if(title.toLowerCase().equals("grid")){
                    Drawable newicon = requireContext().getDrawable(R.drawable.ic_view_list_black_24dp);
                    item.setIcon(newicon);
                    item.setTitle("List");
                    mRecyclerView.setLayoutManager(mGridManager);
                    mAdapter.setManager(false);
                } else{
                    Drawable newIcon = requireContext().getDrawable(R.drawable.ic_view_module_black_24dp);
                    item.setIcon(newIcon);
                    item.setTitle("Grid");
                    mRecyclerView.setLayoutManager(mLinearManager);
                    mAdapter.setManager(true);
                }

                mAdapter.notifyDataSetChanged();
            }
        });
    }

    private void parentFileSize(final Map<MediaFile, List<MediaFile>> file){

        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for(MediaFile f : file.keySet()){

                    long size = 0;
                    List<MediaFile> child = file.get(f);
                    if(child == null) continue;
                    for(MediaFile fi : child){
                        size+=fi.getSize();
                    }
                    f.setSize(size);
                }
            }
        });
    }

    @Override
    public void onFileChanged(String changedFile){

        if(!changedFile.equals("")) {
            //a new file has been added or renamed
            File fi = new File(changedFile);
            List<MediaFile> childs = mFileInfos.get(new MediaFile(fi.getParent()));
            int changedChild = MediaUtils.changedFileIndex(childs);
            String strayThumb = ThumbnailUtils.getUtils().getThumbnailDir();
            if(strayThumb == null) strayThumb = childs.get(changedChild).getThumbnailPath();

            MediaUtils.renameFile(null, strayThumb, fi.getName());


            if (changedChild != -1) childs.get(changedChild).updateFilePath(changedFile);
            else childs.add(new MediaFile(fi.getPath()));
        }else{
            //a file has been deleted or renamed
            MediaFile parent = MediaUtils.changedParentIndex(mFileInfos);
            if(parent == null) return;
            List<MediaFile> children = mFileInfos.get(parent);
            int changedIndex = MediaUtils.changedFileIndex(children);
            MediaFile toBeRemoved = children.get(changedIndex);
            ThumbnailUtils.getUtils().setThumbnailDir(toBeRemoved.getThumbnailPath());
            children.remove(changedIndex);
            ThumbnailUtils.getUtils().removeThumbnail(new Handler());
        }

        mAdapter.notifyDataSetChanged();
    }

}

