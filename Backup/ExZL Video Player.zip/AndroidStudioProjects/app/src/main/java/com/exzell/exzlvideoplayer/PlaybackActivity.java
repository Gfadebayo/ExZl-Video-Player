package com.exzell.exzlvideoplayer;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Bundle;

import com.exzell.exzlvideoplayer.fragments.MediaDialogFragment;
import com.exzell.exzlvideoplayer.viewmodels.MainViewModel;
import com.google.android.material.appbar.AppBarLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class PlaybackActivity extends AppCompatActivity {

    private final String KEY_COMPLETE = "completed";
    private final String KEY_PENDING = "pending";
    private MainViewModel mViewModel;
    public static final String TAG = "PlaybackActivity";
    private File mVideoPlaying;
    private CustomPlayer mCustomPlayer;
    private Set<File> mFiles;
    private Map<String, LinkedList<String>> mPlayList;
    private AppBarLayout mDefaultToolbar;
    private WindowManager.LayoutParams defaultParams;
    private Runnable mExitRunnable;
    private Handler mHandler;
    private boolean isExiting;
    private Toolbar mToolbar;
    private AlertDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playback);
        mToolbar = findViewById(R.id.toolbar1);
        mHandler = new Handler();
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mPlayList = new HashMap<>();
        mPlayList.put(KEY_COMPLETE, new LinkedList<String>());
        mPlayList.put(KEY_PENDING, readReceivedFiles());

        mCustomPlayer = new CustomPlayer(this);
        initVideo(null);
        completedListener();
        nextAndPrevious();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                playbackRateDialog();
            }
        }, 3000);

        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);


    }

    private LinkedList<String> readReceivedFiles(){
        ArrayList<String> vids = getIntent().getStringArrayListExtra(TAG);

        return new LinkedList<>(vids);
    }

    private void initVideo(String name){
        String currentFile;

        if(name != null){
            mPlayList.get(KEY_PENDING).removeFirstOccurrence(name);
            mPlayList.get(KEY_COMPLETE).offerLast(name);
        }

        currentFile = mPlayList.get(KEY_PENDING).peekFirst();

        if(currentFile == null) {
//            isExiting = true;
//            finish();
            return;
        } else {
            mCustomPlayer.setUpPlayer(new File(currentFile));
            mCustomPlayer.startPlaying();
        }

        Drawable drawable = getDrawable(R.drawable.ic_arrow_back_black_24dp);
        drawable.setTint(Color.WHITE);
        mToolbar.setNavigationIcon(drawable);

        String fileName = new File(mPlayList.get(KEY_PENDING).peekFirst()).getName();
        mToolbar.setTitle(fileName);

    }

    private void completedListener(){

//        mCustomPlayer.setOnVideoCompletedListener(new MediaPlayer.OnCompletionListener() {
//            @Override
//            public void onCompletion(MediaPlayer mp) {
//                initVideo(mCustomPlayer.getFilePath());
//            }
//        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        mCustomPlayer.pause();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCustomPlayer.exitPlayer();
    }

    //    private void modifyConfig(){
//
//        AppBarLayout toolBarLay = (AppBarLayout) getLayoutInflater().inflate(R.layout.activity_main, null, false).findViewById(R.id.toolbar).getParent();
//
//        ((Toolbar) toolBarLay.getChildAt(0)).setTitle(fileName);
//        mDefaultToolbar.setBackground(null);
//    }

    private void nextAndPrevious(){
        View.OnClickListener next = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCustomPlayer.stop();
                String currentFile = mCustomPlayer.getFilePath();
                if(mPlayList.get(KEY_PENDING).isEmpty()) return;
                initVideo(currentFile);
            }
        };

        View.OnClickListener previous = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomPlayer.getCurrentPosition() >=  3 * Math.pow(10, 6)) mCustomPlayer.seekBarSeek(0);
                else {
                    mCustomPlayer.stop();
                    if(mPlayList.get(KEY_COMPLETE).isEmpty()) return;
                    String lastFile = mPlayList.get(KEY_COMPLETE).pollLast();
                    mPlayList.get(KEY_PENDING).offerFirst(lastFile);
                    initVideo(null);
                }
            }
        };

        mCustomPlayer.setNextPrevListeners(next, previous);
    }

    private void playbackRateDialog(){

        mDialog = new AlertDialog.Builder(this)
                .setView(R.layout.view_playback_speed)
                .create();
        mDialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.END);
        mDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {

                dialogListeners();
                ((EditText) PlaybackActivity.this.mDialog.findViewById(R.id.edit_text_speed)).setText(editSpeed(mCustomPlayer.getSpeed()));
            }
        });

        mToolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.show();
            }
        });
//        dialogListeners();
    }

    private void dialogListeners(){
        View.OnClickListener onClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.image_add){
                    mCustomPlayer.increaseSpeed(true);
                }else mCustomPlayer.increaseSpeed(false);
                ((EditText) mDialog.findViewById(R.id.edit_text_speed)).setText(editSpeed(mCustomPlayer.getSpeed()));
            }
        };
        View.OnTouchListener onTouch = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                    v.performClick();
                return true;
            }
        };

        mDialog.findViewById(R.id.image_add).setOnClickListener(onClick);
        mDialog.findViewById(R.id.image_subtract).setOnClickListener(onClick);
//        mDialog.findViewById(R.id.image_add).setOnTouchListener(onTouch);
//        mDialog.findViewById(R.id.image_subtract).setOnTouchListener(onTouch);
    }

    private<T> String editSpeed(T texts){
        String text = texts.toString();
        StringBuilder textBuild = new StringBuilder(text);
        int startIndex = 3;
        if(text.charAt(2) == '0') startIndex = 1;

        return textBuild.delete(startIndex, text.length()).append("x").toString();
    }
}