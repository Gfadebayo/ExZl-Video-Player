package com.exzell.exzlvideoplayer.fragments;

import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

public class MediaDialogFragment extends AppCompatDialogFragment {
    private static AlertDialog dialog;

    public static MediaDialogFragment getInstance(AlertDialog dialogToBeUsed){
        MediaDialogFragment frag = new MediaDialogFragment();
        dialog = dialogToBeUsed;
        return frag;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return dialog;
    }

    @Override
    public Dialog getDialog() {
        return dialog;
    }
}
