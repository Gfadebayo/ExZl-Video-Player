package com.exzell.exzlvideoplayer;

import android.os.Bundle;
import android.provider.MediaStore;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MediaFile {

    private static File thumbDir;

    private static String sortKey;

    private String path;

    private String thumbnailPath;

    private long size;

    private String displayName;

    private boolean isDir;

    private int dateAdded;

    private long duration;


    public static void submitThumbnailDir(File dir){
        thumbDir = dir;
    }

    public MediaFile(String filePath, int fileSize, int dateAdded){
        path = filePath;
        size = fileSize;
        isDir = new File(filePath).isDirectory();
        displayName = new File(filePath).getName();
        thumbnailPath = new File(thumbDir, displayName).getPath();
        this.dateAdded = dateAdded;
        if(!isDir) duration = Long.parseLong(MediaUtils.getMediaDuration(filePath)) * 1000;
    }

    public MediaFile(String path){
        this(path, 0, 0);
        size = MediaUtils.calculateTotalSize(path);
        if(!(new File(thumbnailPath).exists()) && !isDir) MediaUtils.loadThumbIntoCache(thumbDir, path, null);
    }

    public String getPath() {
        return path;
    }

    public String getDisplayName(){return displayName;}

    private void updateDisplayName(String newName){
        displayName = newName;
        thumbnailPath = new File(thumbDir, newName).getPath();
    }

    public void updateFilePath(String newPath){
        File newF = new File(newPath);
        updateDisplayName(newF.getName());
    }

    public boolean isDir(){return isDir;}

    public void setPath(String path) {
        this.path = path;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public void updateThumbnailPath(String thumbnailPath) {
        this.thumbnailPath = thumbnailPath;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public int getDateAdded(){
        return dateAdded;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if(!(obj instanceof MediaFile)) return false;

        MediaFile challenger = (MediaFile) obj;

        if(path.equals(challenger.getPath())) return true;
        else return false;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        for(int i = 0; i < path.length(); i++){
            hash+=path.charAt(i);
        }

        return hash;
    }

    @NonNull
    @Override
    public String toString() {
        return path;
    }

    public enum Sort{
        NAME,
        SIZE,
        DATE,
        DURATION


    }
}
