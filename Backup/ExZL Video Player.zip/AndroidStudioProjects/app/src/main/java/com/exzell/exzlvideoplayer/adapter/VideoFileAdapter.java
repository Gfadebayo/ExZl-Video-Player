package com.exzell.exzlvideoplayer.adapter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.WindowCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.exzell.exzlvideoplayer.FragmentVideos;
import com.exzell.exzlvideoplayer.MediaFile;
import com.exzell.exzlvideoplayer.MediaUtils;
import com.exzell.exzlvideoplayer.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VideoFileAdapter extends RecyclerView.Adapter<VideoFileAdapter.ViewHolder> {

    private final String TAG = getClass().getSimpleName();
    private LayoutInflater mLayoutInflater;
    private Context mContext;
    private List<String> mSelectedViews;
    private List<MediaFile> mFiles;
    private FragmentVideos mFragment;
    private ExecutorService mExecutor;
    private Handler mHandler;
    private boolean isLinear = true;

    public VideoFileAdapter(List<MediaFile> infos, Context context, View parent){

        mLayoutInflater = LayoutInflater.from(context);
        mFiles = infos;
        mContext = context;
        mSelectedViews = new ArrayList<>();
        if(parent != null) mFragment = (FragmentVideos) ((ViewPager) parent).getAdapter().instantiateItem((ViewGroup) parent, ((ViewPager)parent).getCurrentItem());
        mExecutor = Executors.newCachedThreadPool();
        mHandler = new Handler(mContext.getMainLooper());
    }

    public VideoFileAdapter(Context context, Set<MediaFile> withPath){
        this(null, context, null);
        mFiles = new ArrayList<>(withPath);
        mContext = context;
    }

    public void setManager(boolean isLinear){
        this.isLinear = isLinear;
        notifyDataSetChanged();


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if(isLinear) return new ViewHolder(mLayoutInflater.inflate(R.layout.list_view_items, parent, false));
        else return new ViewHolder(mLayoutInflater.inflate(R.layout.list_view_items_grid, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final ViewHolder holding = holder;
        MediaFile file = mFiles.get(position);

        holding.mTextName.setText(file.getDisplayName());
        holding.filePath = file.getPath();
        String mb = holding.sizeInMb(file.getSize());
        holding.mTextSize.setText(mb);

        if(!mFiles.get(0).isDir()) {
            holding.mTextDuration.setText(timeFormat(MediaUtils.microUsToTime(file.getDuration())));

            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    if(holding.mImageView.getDrawable() != null) holding.mImageView.setImageDrawable(null);
                    holding.getThumbNail(holding.filePath);
                }
            });
        }else{
            holding.mTextDuration.setVisibility(View.GONE);
        }

        String condition = holding.mTextName.getText().toString().hashCode() + "_";
        if(mSelectedViews.contains(condition)){
            Drawable check = mContext.getDrawable(R.drawable.ic_check_circle_black_24dp);
            holding.itemView.setBackgroundColor(mContext.getColor(R.color.colorAccent));
            holding.mImageView.setImageDrawable(check);
        }else{
            Drawable defaultt = holding.mDefaultDrawable;
            if(defaultt == null) defaultt = mContext.getDrawable(R.drawable.ic_folder_black_24dp);
            holding.itemView.setBackgroundColor(Color.TRANSPARENT);
            holding.mImageView.setImageDrawable(defaultt);
        }
    }

    private String timeFormat(final int[] mcs){
        String ret = "";

        try {
            ret =
            mExecutor.submit(new Callable<String>() {
                @Override
                public String call() throws Exception {
                    StringBuilder time = new StringBuilder();
                    int len = mcs.length;
                    int i = 0;
                    if (mcs[0] == 0) i = 1;

                    while (i < len) {
                        String ti = Integer.toString(mcs[i]);
                        if (ti.length() == 1) ti = "0" + ti;
                        time.append(ti);
                        time.append(":");
                        i++;
                    }

                    if (time.toString().endsWith(":")) time.deleteCharAt(time.length() - 1);

                    return time.toString();
                }
            }).get();
        }catch(Exception e){e.printStackTrace();}

        return ret;
    }

    @Override
    public int getItemViewType(int position) {
        if(isLinear) return 0;
        else return 1;
    }

    public void endItAll(){
        mHandler.removeCallbacksAndMessages(null);
    }

    @Override
    public int getItemCount() {
        return mFiles.size();
    }

    public List<MediaFile> getFiles(){
        return mFiles;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mTextName;
        public TextView mTextSize;
        private ImageView mImageMore;
        public TextView mTextDuration;
        public String filePath;
        private Drawable mDefaultDrawable;
        private Drawable checkBox;
        private ConstraintLayout mParent;
        private Drawable mAudioNote;
        private Drawable mMovie;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            mParent = itemView.findViewById(R.id.constraint_file);
            mImageView = itemView.findViewById(R.id.image_thumbnail);
            mImageMore = itemView.findViewById(R.id.image_more);
            mTextName = itemView.findViewById(R.id.text_file_name);
            mTextSize = itemView.findViewById(R.id.text_size);
            mTextDuration = itemView.findViewById(R.id.text_duration);
            mTextName.setId(View.generateViewId());
            mAudioNote = mContext.getResources().getDrawable(R.drawable.ic_music_note_black_24dp, null);
            checkBox = mContext.getResources().getDrawable(R.drawable.ic_check_circle_black_24dp, null);
            mMovie = mContext.getResources().getDrawable(R.drawable.ic_movie_black_24dp, null);


            mImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectFile();
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    return selectFile();
                }
            });

            mImageMore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showPopup(v);
                }
            });
        }

        public void getThumbNail(final String sourcePath) {
//            mHandler.post(new Runnable() {
//                @Override
//                public void run() {

                    MediaUtils.MediaOrigins which = MediaUtils.checkFileType(new File(sourcePath));

                    int wid = mImageView.getMaxWidth();
                    int hei = mImageView.getMaxHeight();


                    File app = mContext.getApplicationContext().getExternalCacheDir();

                        Bitmap fileThumb = MediaUtils.getFileThumbnail(app, sourcePath, wid, hei);

                    if (fileThumb != null) mImageView.setImageBitmap(fileThumb);
                    else {
                        if (which == MediaUtils.MediaOrigins.AUDIO)
                            mImageView.setImageDrawable(mAudioNote);
                        else mImageView.setImageDrawable(mMovie);
                    }
                    if (mDefaultDrawable == null) mDefaultDrawable = mImageView.getDrawable();
//                }
//            });
        }

        public String sizeInMb(final long size){
            String siz = null;

            try {
                siz =
                mExecutor.submit(new Callable<String>() {
                    @Override
                    public String call() {
                        Float integer = Float.valueOf(size);
                        //size in kb
                        float mbSize = integer / 1000;


                        if (mbSize < 1024) {
                            String mb = String.format("%3dKB", (int) mbSize);
//                int decimalIndex = mb.indexOf(".");
                            return mb;
                        } else if (mbSize >= 1024 && mbSize < (1000 * 1000)) {
                            float mb = mbSize / 1024;
                            String mbb = String.format("%.2fMB", mb);
//                int decimalIndex = mb.indexOf(".");
                            return mbb;
                        } else {
                            float gb = mbSize / (1024 * 1024);
                            String gbb = String.format("%.2fGB", gb);
                            return gbb;
                        }
                    }
                }).get();
            }catch(Exception e){
                e.printStackTrace();
            }

            return siz;
        }

        public String getPath(){
            return filePath;
        }

        public boolean selectFile() {
            if(mDefaultDrawable == null) mDefaultDrawable = mImageView.getDrawable();

            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    ColorDrawable background = (ColorDrawable) mParent.getBackground();

                    if (background.getColor() == mContext.getColor(R.color.colorAccent)) {
                        mImageView.setImageDrawable(mDefaultDrawable);
                        (mParent).setBackgroundColor(Color.WHITE);
                        mSelectedViews.remove(mTextName.getText().toString().hashCode() + "_");
                        if (mFragment != null) mFragment.selectFiles(filePath, false);
                    } else {
                        mImageView.setImageDrawable(checkBox);
                        (mParent).setBackgroundColor((mContext.getColor(R.color.colorAccent)));
                        final String nameFile = mTextName.getText().toString().hashCode() + "_";
                        mSelectedViews.add(nameFile);
                        if (mFragment != null) mFragment.selectFiles(filePath, true);
                    }
                }
            });

            return true;
        }

        @SuppressLint("RestrictedApi")
        public void showPopup(View view) {
            MenuBuilder menuBuilder = new MenuBuilder(mContext);
            new MenuInflater(mContext).inflate(R.menu.menu_popup_more, menuBuilder);
            MenuPopupHelper popHelp = new MenuPopupHelper(mContext, menuBuilder, view);
            popHelp.setForceShowIcon(true);

            menuBuilder.setCallback(new MenuBuilder.Callback() {
                @Override
                public boolean onMenuItemSelected(MenuBuilder menu, MenuItem item) {
                    performPopupAction(item.getItemId());
                    Log.i(TAG, "Menu item clicked");
                    return true;
                }

                @Override
                public void onMenuModeChange(MenuBuilder menu) { }
            });

            popHelp.show();
        }

        private void performPopupAction(int itemId) {
            switch(itemId){
                case R.id.action_change_thumb:
                    popUpDialog(0);
                    break;
                case R.id.action_delete:
                    popUpDialog(1);
                    break;
                case R.id.action_rename:
                    popUpDialog(2);
                    break;
            }
        }

        private void popUpDialog(final int kind){

            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    String title = null;
                    if(kind == 0) title = "Enter desired time";
                    else if(kind == 2) title = "New Name";

                    final AlertDialog simpDia = new AlertDialog.Builder(mContext)
                            .setTitle(title)
                            .setNegativeButton("Cancel", createDialogListener(kind, null))
                            .setOnDismissListener(new DialogInterface.OnDismissListener() {
                                @Override
                                public void onDismiss(DialogInterface dialog) {
                                    notifyDataSetChanged();
                                }
                            })
                            .create();

                    //A simple edit text to change the name
                    if (kind == 2) simpDia.setView(dialogEditText(simpDia));
                        //Three pickers showing the respective time unit
                    else if(kind == 0) {
                        final LinearLayout picker = createDialogPicker();
                        simpDia.setView(picker);
                        simpDia.setButton(AlertDialog.BUTTON_POSITIVE, "Change Thumbnail", createDialogListener(kind, picker));

                    } else {
                        simpDia.setMessage("Are you sure you want to delete this File \nThis operation cannot be undone");
                        simpDia.setButton(AlertDialog.BUTTON_POSITIVE, "Delete", createDialogListener(kind, null));
                    }

                    simpDia.show();

                    changeDialogForm(simpDia);
                }
            });
        }

        private EditText dialogEditText(final AlertDialog parent){
            final EditText simpEdit = (EditText) mLayoutInflater.inflate(R.layout.switch_item, null, false);
            simpEdit.setText(mTextName.getText());

            simpEdit.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override
                public void onViewAttachedToWindow(View v) {
                    simpEdit.requestFocus();
                    int extensionStartIndex = mTextName.getText().toString().lastIndexOf(".");
                    simpEdit.setSelection(0, extensionStartIndex);


                }

                @Override
                public void onViewDetachedFromWindow(View v) {
                   simpEdit.removeOnAttachStateChangeListener(this);
                }
            });


            simpEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if(actionId != EditorInfo.IME_NULL) return false;

                    parent.cancel();

                    boolean done = MediaUtils.renameFile(mContext, filePath, v.getText().toString());
                    if(done) Toast.makeText(mContext, "Renamed Successfully", Toast.LENGTH_SHORT).show();
                    else Toast.makeText(mContext, "Rename Failed", Toast.LENGTH_SHORT).show();

                    return true;
                }
            });

            return simpEdit;
        }

        private DialogInterface.OnClickListener createDialogListener(final int kind, final View v){
            return new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(which == Dialog.BUTTON_POSITIVE) {
                        if (kind == 1) {
                            boolean done = MediaUtils.deleteFile(mContext, filePath);
                            if (done)
                                Toast.makeText(mContext, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                        } else v.performClick();
                    }else dialog.cancel();
                }
            };
        }

        private void changeDialogForm(AlertDialog dia){
            View diaDecor = dia.getWindow().peekDecorView();
            dia.getWindow().setGravity(Gravity.CENTER);

            WindowManager.LayoutParams diaParams = (WindowManager.LayoutParams) diaDecor.getLayoutParams();
            if(diaParams != null){
                diaParams.width = diaParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dia.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            }
        }

        private LinearLayout createDialogPicker(){
            final LinearLayout parent = new LinearLayout(mContext);
            parent.setOrientation(LinearLayout.HORIZONTAL);
            parent.setGravity(Gravity.CENTER);

            WindowManager.LayoutParams pa = new WindowManager.LayoutParams();
            pa.width = pa.height = WindowManager.LayoutParams.WRAP_CONTENT;
            parent.setLayoutParams(pa);

            LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dotParams.setMarginStart(4);
            dotParams.setMarginEnd(4);
            LinearLayout.LayoutParams pickParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            long timeUs = MediaUtils.timeInUs(mTextDuration.getText().toString());
            int[] times = MediaUtils.microUsToTime(timeUs);
            int startIndex = 0;
            if(times[0] == 0) startIndex = 1;

            for (int i = startIndex; i < times.length; i++) {
                int t = times[i];
                final TextView dot = new TextView(mContext);
                dot.setText(":");
                dot.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                dot.setGravity(Gravity.CENTER);

                NumberPicker pick = new NumberPicker(mContext);
                pick.setMinValue(0);
                pick.setMaxValue(t);
                pick.setFormatter(new NumberPicker.Formatter() {
                    @Override
                    public String format(int value) {
                        StringBuilder val = new StringBuilder();
                        if(value < 10){
                            val.append(0).append(value);
                        }else val.append(value);

                        return val.toString();
                    }
                });
                pick.setOnLongPressUpdateInterval(2);
                parent.addView(pick, pickParams);

                parent.addView(dot, dotParams);
            }

            parent.removeViewAt(parent.getChildCount() - 1);

            parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int childCount = parent.getChildCount();
                    StringBuilder time = new StringBuilder();
                    for(int i = 0; i < childCount; i++){
                        View c = parent.getChildAt(i);
                        if(c instanceof NumberPicker) time.append(((NumberPicker) c).getValue());
                        else time.append(((TextView) c).getText().toString());
                    }
                    MediaUtils.loadThumbIntoCache(mContext.getExternalCacheDir(), filePath, time.toString());

                }
            });

            return parent;
        }
    }
}
