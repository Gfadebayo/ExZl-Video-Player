package com.example.championsleague;

import org.junit.Test;

import static org.junit.Assert.*;

public class LeagueTest {

    @Test
    public void generateFixtures() {


    }
}