package com.example.championsleague.ui.home;

import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.championsleague.FixtureRecyclerAdapter;
import com.example.championsleague.R;
import com.example.championsleague.TeamSelectionActivity;
import com.example.championsleague.models.FixtureInfo;
import com.example.championsleague.models.LeagueInfo;
import com.example.championsleague.models.TeamInfo;
import com.example.championsleague.ui.TeamDialogFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private RecyclerView fixtureView;
    private FixtureRecyclerAdapter fixtureRecyclerAdapter;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_home, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        homeViewModel = new ViewModelProvider(requireActivity(),
                ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity()
                        .getApplication())).get(HomeViewModel.class);

        List<FixtureInfo> fixtures = homeViewModel.getFixtures();
        Map<Integer, int[]> predictedScores = homeViewModel.getPredictedScores();
//        Map<String, Bitmap> teamLogos = getTeamLogos();
        fixtureRecyclerAdapter = new FixtureRecyclerAdapter(requireActivity(), fixtures, predictedScores);
        fixtureView = view.findViewById(R.id.fixture_view);
        fixtureView.setAdapter(fixtureRecyclerAdapter);

        view.findViewById(R.id.fab_mass_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int counter = homeViewModel.getFixtures().size();
                        updateWithoutUndo();

//                    fixtureRecyclerAdapter.notifyDataSetChanged();
//                    fixtureRecyclerAdapter.notifyItemRangeRemoved(0, fixtureView.getChildCount());
//                    fixtureRecyclerAdapter.notify
//                            fixtureRecyclerAdapter.notifyItemChanged(i);
                }
            });
        }

//        view.findViewById(R.id.submit_butt).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                updateFixtures();
//            }
//        });
//        findingButton();
//
//        butt.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                updateFixtures();
//            }
//        });

//    public void findingButton(){
//        View v = getLayoutInflater().inflate(R.layout.list_fixtures, null, false);
//
//        butt = v.findViewById(R.id.submit_butt);
//    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {

        inflater.inflate(R.menu.fragment_menu, menu);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        boolean isRightMenu = false;
        int menuId = item.getItemId();

        switch (menuId) {
            case (R.id.action_undo):
                updateFixtures(false);
                isRightMenu = true;
                break;
            case (R.id.action_leg_1):
                homeViewModel.mLeg = 1;
                item.setChecked(true);
                isRightMenu = true;
                break;
            case (R.id.action_leg_2):
                homeViewModel.mLeg = 2;
                item.setChecked(true);
                isRightMenu = true;
                break;
            case (R.id.action_leg_both):
                homeViewModel.mLeg = 0;
                item.setChecked(true);
                isRightMenu = true;
                break;
            case (R.id.action_team):
                createDialog();
                isRightMenu = true;
                break;
            case (R.id.action_predict):
                predictScores();
                isRightMenu = true;
        }
        if(isRightMenu) destroyAndRecreate(true);

        return isRightMenu;
    }

    private void predictScores() {
        List<FixtureInfo> currentlyShownFixtures = homeViewModel.getFixtures();
        List<int[]> predictedScores = LeagueInfo.getInstance().generateRandomScores(currentlyShownFixtures.size());
        for(int i = 0; i < currentlyShownFixtures.size(); i++) {
            if(homeViewModel.getPredictedScores().keySet().contains(currentlyShownFixtures.get(i).getFixtureNo())) continue;
            homeViewModel.getPredictedScores().put(currentlyShownFixtures.get(i).getFixtureNo(), predictedScores.get(i));
        }
    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {

        MenuItem item = menu.findItem(R.id.action_undo);
        if (LeagueInfo.currentFrameLayout.isEmpty()) item.setEnabled(false);
        else item.setEnabled(true);

        if (homeViewModel.mLeg == 1) {
            menu.findItem(R.id.action_leg_1).setChecked(true);
        } else if (homeViewModel.mLeg == 2) {
            menu.findItem(R.id.action_leg_2).setChecked(true);
        } else {
            menu.findItem(R.id.action_leg_both).setChecked(true);
        }

        super.onPrepareOptionsMenu(menu);
    }

    //if this does'nt work, inflate the list_fixtures file and implement the onclick using the button id
    //if isEvaluating is true, this method is originally called by the onClick which is created in the activity class
    public void updateFixtures(final boolean isEvaluating) {
        int homeScore;
        int awayScore;
        int fixtureNo;
        int adapterPosition;

        if(isEvaluating) {
            int itemViewId = LeagueInfo.currentFrameLayout.get(LeagueInfo.currentFrameLayout.size() - 1);
            FixtureRecyclerAdapter.ViewHolder hold = (FixtureRecyclerAdapter.ViewHolder) fixtureView.getChildViewHolder(fixtureView.findViewById(itemViewId));
            fixtureNo = Integer.parseInt(hold.fixtureNo.getText().toString().split("\\s+")[1]);
            adapterPosition = fixtureView.getChildAdapterPosition(fixtureView.findViewById(itemViewId));
            homeScore = Integer.parseInt(hold.homeScore.getEditText().getText().toString());
            awayScore = Integer.parseInt(hold.awayScore.getEditText().getText().toString());
        }else{
            homeScore = -1;
            awayScore = -1;
            fixtureNo = homeViewModel.getSubmittedFixtureNo().get(homeViewModel.getSubmittedFixtureNo().size() - 1);
            LeagueInfo.currentFrameLayout.remove((Object) fixtureNo);
            adapterPosition = fixtureNo - 1;
        }

        FixtureRecyclerAdapter.ViewHolder holdedView = (FixtureRecyclerAdapter.ViewHolder) fixtureView.getChildViewHolder(fixtureView.getChildAt(adapterPosition));
        homeViewModel.updateFixtureTable(homeScore, awayScore, fixtureNo);
        List<TeamInfo> list = homeViewModel.getSelectedTeams(fixtureNo);
        FixtureInfo fixes = homeViewModel.fixture(fixtureNo);
        List<TeamInfo> teamInfoList = LeagueInfo.getInstance().evaluateResult(fixes, list, isEvaluating);
        homeViewModel.updateTeamDb(teamInfoList);
        destroyAndRecreate(fixtureRecyclerAdapter.updateFixture(isEvaluating, holdedView, fixes, null));


        homeViewModel.setSubmittedFixtureNo(isEvaluating, fixtureNo);


        if(LeagueInfo.currentFrameLayout.size() <= 1) {
            requireActivity().invalidateOptionsMenu();
        }
    }

    public void createDialog() {

        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final List<String> chosenTeams = new ArrayList<>(4);
                final List<String> teams = homeViewModel.getTeamNames();
                final boolean[] checkedTeams = new boolean[teams.size()];
                for (int i = 0; i < teams.size(); i++) {
                    if (homeViewModel.mTrimTeams.contains(teams.get(i))) checkedTeams[i] = true;
                    else checkedTeams[i] = false;
                }


                AppCompatDialog dia = new AlertDialog.Builder(requireActivity())
                        .setMultiChoiceItems(teams.toArray(new String[0]), checkedTeams, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                                if (!isChecked) {
                                    checkedTeams[which] = false;
                                } else checkedTeams[which] = true;
                            }
                        }).setTitle("Select the Teams").setPositiveButton("Choose Teams", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                homeViewModel.mTrimTeams.clear();
                                for (int i = 0; i < checkedTeams.length; i++) {
                                    if (checkedTeams[i]) homeViewModel.mTrimTeams.add(teams.get(i));
                                }

                                destroyAndRecreate(fixtureRecyclerAdapter.setNewFixtures(homeViewModel.getFixtures()));
                                dialog.dismiss();
                            }
                        }).create();

                dia.show();
            }
        });
    }

    public void changedData(final FixtureRecyclerAdapter adapter, final List<FixtureInfo> newFixtures) {
        DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override
            public int getOldListSize() {
                return adapter.getItemCount();
            }

            @Override
            public int getNewListSize() {
                return newFixtures.size();
            }

            @Override
            public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                return adapter.getItemId(oldItemPosition) == adapter.getItemId(newItemPosition);
            }

            @Override
            public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                return adapter.getFixtures().get(oldItemPosition).equals(newFixtures.get(newItemPosition));
            }
        }).dispatchUpdatesTo(adapter);
    }


    private void destroyAndRecreate(final boolean isDestroying) {
                if (isDestroying) {
                    requireActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            NavController navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment);

                            int fragId = navController.getCurrentDestination().getId();

                            navController.navigate(fragId);
                        }
                    });
                }
            }

    private boolean updateWithoutUndo(){
        Map<Integer, int[]> predictedScores = homeViewModel.getPredictedScores();
        for(int fixtureNo : predictedScores.keySet()) {
            int awayScore = predictedScores.get(fixtureNo)[1];
            int homeScore = predictedScores.get(fixtureNo)[0];
            FixtureInfo fix = homeViewModel.fixture(fixtureNo);
            List<TeamInfo> currentTeams = homeViewModel.getSelectedTeams(fixtureNo);
            currentTeams = LeagueInfo.getInstance().evaluateResult(fix, currentTeams, true);

            homeViewModel.updateTeamDb(currentTeams);
            homeViewModel.updateFixtureTable(homeScore, awayScore, fixtureNo);
            fixtureRecyclerAdapter.changeFixtures(fix);

            fixtureRecyclerAdapter.notifyDataSetChanged();
        }

        return false;
    }

//    private Map<String, Bitmap> getTeamLogos(){
//        Map<String, Bitmap> images = new HashMap<>();
//        try {images.putAll(
//            executorService.submit(new Callable<Map<String, Bitmap>>() {
//                @Override
//                public Map<String, Bitmap> call() throws Exception {
//                    Bundle arguments = getArguments();
//                    Set<String> keys = arguments.keySet();
//                    Map<String, Bitmap> image = new HashMap<>();
//                    ContentResolver cr = requireActivity().getContentResolver();
//                    for (String ki : keys) {
//                        Bitmap bitmap = BitmapFactory.decodeFileDescriptor(cr.openFileDescriptor((Uri) arguments.getParcelable(ki), "r").getFileDescriptor());
//                        image.put(ki, bitmap);
//                    }
//
//                    return image;
//                }
//            }).get());
//        }catch(Exception e){e.printStackTrace();}
//
//        return images;
//    }
    }
