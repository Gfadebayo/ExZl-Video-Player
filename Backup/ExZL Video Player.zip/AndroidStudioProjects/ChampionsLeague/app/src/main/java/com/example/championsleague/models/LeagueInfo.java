package com.example.championsleague.models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import androidx.annotation.Nullable;

import com.example.championsleague.FixtureRecyclerAdapter;
import com.example.championsleague.database.LeagueRepository;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LeagueInfo {

    private static LeagueInfo ourInstance;
    public static List<Integer> currentFrameLayout = new ArrayList<>();
    private ExecutorService leagueExecutor;

    public static LeagueInfo getInstance() {

        if (ourInstance == null) {
            ourInstance = new LeagueInfo();
        }
        return ourInstance;
    }

    private LeagueInfo() {
        leagueExecutor = Executors.newFixedThreadPool(6);
    }

    public List<FixtureInfo> generateFixtures(final List<TeamInfo> presentTeam,@Nullable final List<FixtureInfo> oldFixtures) {
        List<FixtureInfo> ture = new ArrayList<>();
        try {
            ture = leagueExecutor.submit(new Callable<List<FixtureInfo>>() {
                @Override
                public List<FixtureInfo> call() throws Exception {
                    int noOfFixtures = presentTeam.size() * (presentTeam.size() - 1);
                    int fixtureStart = 0;
                    FixtureInfo[] turesArr = new FixtureInfo[noOfFixtures];
                    for (int j = 0; j < presentTeam.size() - 1; j++) {

                        for (int k = j + 1; k < presentTeam.size(); k++) {

                            if (k == j) continue;

//                homeFixtures.add(new FixtureInfo(presentTeams.get(j), presentTeams.get(k), 1));
//
//                awayFixtures.add(new FixtureInfo(presentTeams.get(k), presentTeams.get(j), 2));

                            TeamInfo home = presentTeam.get(j);
                            TeamInfo away = presentTeam.get(k);

                            turesArr[fixtureStart] = new FixtureInfo(home.getTeamName(), away.getTeamName(), 1);
                            turesArr[(noOfFixtures - 1)] = new FixtureInfo(away.getTeamName(), home.getTeamName(), 2);

                            noOfFixtures--;
                            fixtureStart++;
                        }
                    }
                    List<FixtureInfo> tures = Arrays.asList(turesArr);
                    if (oldFixtures != null) {
                        //remove the current fixtures without scores
                        //then add the information of the old one into the new one
                        for(int i = 0; i < oldFixtures.size(); i++){
                            //strip the old fixtures of their fixture numbers
                            if(tures.contains(oldFixtures.get(i))){
                                oldFixtures.get(i).setFixtureNo(0);
                                tures.set(i, oldFixtures.get(i));
                            }
                        }
                    }

                    Collections.shuffle(tures.subList(0, (tures.size() / 2)));
                    Collections.shuffle(tures.subList(tures.size() / 2, tures.size()));

                    return incrementFixtureOrTeam(tures, oldFixtures);
                }
            }).get();
        }catch(Exception e){e.printStackTrace();}





//        List<FixtureInfo> tures = new ArrayList<>();
//        int noOfFixtures = presentTeams.size() * (presentTeams.size() - 1);
//        int fixtureStart = 0;
//        for (int j = 0; j < presentTeams.size() - 1; j++) {
//
//            for (int k = j + 1; k < presentTeams.size(); k++) {
//
//                if (k == j) continue;
//
////                homeFixtures.add(new FixtureInfo(presentTeams.get(j), presentTeams.get(k), 1));
////
////                awayFixtures.add(new FixtureInfo(presentTeams.get(k), presentTeams.get(j), 2));
//
//                String home = presentTeams.get(j);
//                String away = presentTeams.get(k);
//
//                tures.add(fixtureStart, new FixtureInfo(home, away, 1, presentTeam.get(home), presentTeam.get(away)));
//                tures.add((noOfFixtures - 1), new FixtureInfo(away, home, 2, presentTeam.get(away), presentTeam.get(home)));
//
//                noOfFixtures--;
//                fixtureStart++;
//            }
//        }
//
//        if (oldFixtures != null) {
//            //remove the current fixtures without scores
//            //then add the information of the old one into the new one
//            for(int i = 0; i < oldFixtures.size(); i++){
//                //strip the old fixtures of their fixture numbers
//                if(tures.contains(oldFixtures.get(i))){
//                    oldFixtures.get(i).setFixtureNo(0);
//                    tures.set(i, oldFixtures.get(i));
//                }
//            }
//        }
//
//        Collections.shuffle(tures.subList(0, (tures.size() / 2)));
//        Collections.shuffle(tures.subList(tures.size() / 2, tures.size()));
//
//        return incrementFixtureOrTeam(tures, oldFixtures);

        return ture;
    }

    public List<TeamInfo> createTeams(final Map<String, String> teamsLogo, final List<TeamInfo> oldTeamNames){
       List<TeamInfo> leagueTeam = new ArrayList<>();

       try {
           leagueTeam = leagueExecutor.submit(new Callable<List<TeamInfo>>() {
               List<TeamInfo> leagueTeams = new ArrayList<>();
               @Override
               public List<TeamInfo> call() throws Exception {
                   for (String logoKey : teamsLogo.keySet()) {

                       TeamInfo team = new TeamInfo(logoKey, teamsLogo.get(logoKey));

                       leagueTeams.add(team);
                   }

                   if (oldTeamNames != null) {
                       for(TeamInfo old : oldTeamNames){
                           if(leagueTeams.contains(old)) leagueTeams.set((old.getCurrentPoint() - 1), old);
                       }
                   }

                   Collections.sort(leagueTeams);

                   return incrementFixtureOrTeam(leagueTeams, oldTeamNames);
               }
           }).get();
       }catch(Exception e){e.printStackTrace();}

       return leagueTeam;
    }

    public List<TeamInfo> evaluateResult(FixtureInfo result, List<TeamInfo> involvedTeams, boolean isEvaluating){

        //since a linkedlist is used to store team info, there is no further need to find the home or away team
        //as the index 0 contains the home team and 1 contains the away team

        int goalDiff = result.getHomeScore() - result.getAwayScore();

        if(isEvaluating) {
            if (goalDiff > 0) {
                involvedTeams.get(0).incrementPoint(3);
                involvedTeams.get(0).setWins(involvedTeams.get(0).getWins() + 1);
                involvedTeams.get(1).setLosses(involvedTeams.get(1).getLosses() + 1);
            } else if (goalDiff < 0) {
                involvedTeams.get(1).incrementPoint(3);
                involvedTeams.get(1).setWins(involvedTeams.get(1).getWins() + 1);
                involvedTeams.get(1).setLosses(involvedTeams.get(0).getLosses() + 1);
            } else {
                involvedTeams.get(0).incrementPoint(1);
                involvedTeams.get(1).incrementPoint(1);
                involvedTeams.get(0).setDraws(involvedTeams.get(0).getDraws() + 1);
                involvedTeams.get(1).setDraws(involvedTeams.get(1).getDraws() + 1);
            }

            involvedTeams.get(0).incrementGoalDiff(goalDiff);
            involvedTeams.get(1).incrementGoalDiff(-goalDiff);

            involvedTeams.get(0).setId(involvedTeams.get(0).getId() + 1);
            involvedTeams.get(1).setId(involvedTeams.get(1).getId() + 1);
        }
        else{

            if(goalDiff > 0){
                involvedTeams.get(0).incrementPoint(-3);
                involvedTeams.get(0).setWins(involvedTeams.get(0).getWins() - 1);
                involvedTeams.get(1).setLosses(involvedTeams.get(1).getLosses() - 1);
            }else if(goalDiff < 0){
                involvedTeams.get(1).incrementPoint(-3);
                involvedTeams.get(1).setWins(involvedTeams.get(1).getWins() - 1);
                involvedTeams.get(1).setLosses(involvedTeams.get(0).getLosses() - 1);
            }else{
                involvedTeams.get(0).incrementPoint(-1);
                involvedTeams.get(1).incrementPoint(-1);
                involvedTeams.get(0).setDraws(involvedTeams.get(0).getDraws() - 1);
                involvedTeams.get(1).setDraws(involvedTeams.get(1).getDraws() - 1);
            }
            involvedTeams.get(0).setId(involvedTeams.get(0).getId() - 1);
            involvedTeams.get(1).setId(involvedTeams.get(1).getId() - 1);

            involvedTeams.get(0).setCurrentGoalDifference(-goalDiff);
            involvedTeams.get(1).setCurrentGoalDifference(goalDiff);
        }

        return involvedTeams;
    }

//    public void setNewTeams(List<String> newTeams){
//        List<TeamInfo> newTeam = new ArrayList<>();
//
//        for(int i = 0; i < newTeams.size(); i++){
//
//            TeamInfo team_x = new TeamInfo(newTeams.get(i));
//
//            newTeam.add(team_x);
//        }
//
////        leagueRepo.changeTeams(oldTeams, newTeam);
//
//    }

    public <T> List<T> incrementFixtureOrTeam(List<T> required, List<T> oldValues){
        if(oldValues == null) oldValues = new ArrayList<>();

        if(required.get(0) instanceof TeamInfo){

            for(int i = 0; i < required.size(); i++) {
                if(oldValues.contains(required.get(i))) continue;
                ((TeamInfo) required.get(i)).setCurrentPosition(i + 1);
            }

        }else{

            int remainingNo = required.size() - oldValues.size();
            List<T> ts = required.subList(0, remainingNo);
            for(int i = 0; i < required.size(); i++){
                ((FixtureInfo) ts.get(i)).setFixtureNo(oldValues.size() + i + 1);
            }
        }
        return required;
    }

    public List<FixtureInfo> removeDuplicates(List<FixtureInfo> duplicates){

        List<FixtureInfo> noDuplicates = new ArrayList<>(duplicates.size());


        for(FixtureInfo f : duplicates){
            boolean isContain = false;
            if(noDuplicates.isEmpty()){
                noDuplicates.add(f);
                continue;
            }

            for(int i = 0; i < noDuplicates.size(); i++){
                if(f.getFixtureNo() == noDuplicates.get(i).getFixtureNo()){
                    isContain = true;
                    break;
                }
            }

            if(!isContain) noDuplicates.add(f);
        }

        return noDuplicates;
    }

    public List<int[]> generateRandomScores(int noOfFixtures){
        List<int[]> scores = new ArrayList<>(noOfFixtures);

        for(int i = 0; i < noOfFixtures; i++){

            int[] randomScores = {((int)Math.ceil(Math.random() * 5)), ((int)Math.ceil(Math.random() * 5))};
            scores.add(randomScores);
        }

        return scores;
    }
}
