package com.example.championsleague;

import android.app.Application;
import android.graphics.BitmapFactory;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;

import com.example.championsleague.database.LeagueRepository;
import com.example.championsleague.models.FixtureInfo;
import com.example.championsleague.models.TeamInfo;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivityViewModel extends AndroidViewModel {

    private LeagueRepository leagueRepo;
    private SavedStateHandle savedStateHandle;
    private static final String KEY_ID = "text_ids";
    private static final String KEY_SPIN = "spin_position";
    private static final String KEY_NAME = "team_names";
    private static final String KEY_LOGO = "team_logos";
    private List<FixtureInfo> previousSavedFixtures;
    private List<TeamInfo> previousSavedTeams;
    private MutableLiveData<List<String>> existingTeams;


    public MainActivityViewModel(Application app, SavedStateHandle handle) {
        super(app);
        leagueRepo = LeagueRepository.getInstance(app);
        savedStateHandle = handle;
        MutableLiveData<List<TeamInfo>> inform = new MutableLiveData<>();
        inform.postValue(new ArrayList<TeamInfo>());
    }


    LiveData<List<Integer>> getTextViewIds(){
        return savedStateHandle.getLiveData(KEY_ID);
    }

    LiveData<List<String>> getTeamNames(){
        return savedStateHandle.getLiveData(KEY_NAME);
    }

    LiveData<Integer> getSpinnerValue(){
        return  savedStateHandle.getLiveData(KEY_SPIN);
    }

    LiveData<Map<String, String>> getTeamInfo(){ return savedStateHandle.getLiveData(KEY_LOGO);}

    public void setNewSpinnerValue(int newValue){
        savedStateHandle.set(KEY_SPIN, newValue);
    }

    public void setNewTeamIds(List<Integer> id){
        savedStateHandle.set(KEY_ID, id);
    }

    public void setNewTeamName(List<String> newName){
        savedStateHandle.set(KEY_NAME, newName);
    }

    public void setTeamInfo(Map<String, String> logos){ savedStateHandle.set(KEY_LOGO, logos);}

    public void initialHandleValues(){

        ExecutorService threadExecutor = Executors.newFixedThreadPool(3);
        try {
            threadExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    if (!savedStateHandle.contains(KEY_ID)) {
                        setNewTeamIds(new ArrayList<Integer>());
                    }

                    if (!savedStateHandle.contains(KEY_NAME)) {
                        setNewTeamName(new ArrayList<String>());
                    }

                    if (!savedStateHandle.contains(KEY_SPIN)) {
                        setNewSpinnerValue(0);
                    }

                    if(!savedStateHandle.contains(KEY_LOGO)){
                        setTeamInfo(new HashMap<String, String>());
                    }
                }
            });
        }finally{
            threadExecutor.shutdown();
        }
    }

    public LiveData<List<TeamInfo>> insertInfo(){
        return leagueRepo.getCurrentStanding();
    }

    public List<TeamInfo> currentTeamData(){
        return leagueRepo.notLiveTeamInfo();
    }

    public void clearAllNames(){
        leagueRepo.nukeEverything();
    }

    public List<FixtureInfo> getFixtures(){
        return leagueRepo.allFixturesLiveNot(0, null);
    }

    public void removeAllFixtures(){
        leagueRepo.nukeAllFixtures();
    }

    public void addTeams(List<TeamInfo> teamList){
        leagueRepo.insertTeams(teamList);
    }

    public void addFixtures(List<FixtureInfo> fixtureList){
        leagueRepo.insertFixtures(fixtureList);
    }

    public void updateTeams(List<TeamInfo> newTeams){

        leagueRepo.updateTeam(newTeams);
    }

    public <T> void clearSavedValue(int whichToBeCleared){
        if(whichToBeCleared == 0){
            ((List<Integer>)savedStateHandle.get(KEY_ID)).clear();
        }else if(whichToBeCleared == 1){
            ((List<String>)savedStateHandle.get(KEY_NAME)).clear();
        }
    }

    public List<FixtureInfo> getPreviousSavedFixtures(){
        return previousSavedFixtures;
    }

    public List<TeamInfo> getPreviousSavedTeams(){
        return previousSavedTeams;
    }

    public void setPreviouses(boolean isNewActivity){

        if(!isNewActivity) return;
        Map<String, String> prev = savedStateHandle.get(KEY_LOGO);
        if(previousSavedFixtures == null){
            previousSavedFixtures = new ArrayList<>();
            previousSavedTeams = new ArrayList<>();
        }
        List<FixtureInfo> currentDbFix = getFixtures();
        List<TeamInfo> currTeam = currentTeamData();
        for(int i = 0; i < currentDbFix.size() / 2; i++){
            if(i < currTeam.size() && prev.containsKey(currTeam.get(i).getTeamName())){
                try{
                currTeam.get(i).setLogo(BitmapFactory.decodeStream(new FileInputStream(prev.get(currTeam.get(i).getTeamName()))));
                }catch(Exception e){
                    e.printStackTrace();
                }
            }

            if(currentDbFix.get(i).getHomeLogo() != null) continue;
            if(currentDbFix.get(i).getHomeTeam().equals(currTeam.get(i).getTeamName()) && currTeam.get(i).getLogo() != null){
                currentDbFix.get(i).setHomeLogo(currTeam.get(i).getLogo());
            }
        }


        previousSavedTeams.clear();
        previousSavedFixtures.clear();
        previousSavedFixtures.addAll(currentDbFix);
        previousSavedTeams.addAll(currTeam);
    }

    public LiveData<List<String>> getExistingTeams(){
        if(existingTeams == null){
            existingTeams = new MutableLiveData<>();
            existingTeams.setValue(new ArrayList<String>());
        }
        return existingTeams;
    }
}
