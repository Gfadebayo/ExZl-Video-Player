package com.example.championsleague.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.championsleague.models.TeamInfo;

import java.util.List;

@Dao
public interface TeamDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertTeam(List<TeamInfo> teams);

    @Delete
    void deleteTeam(TeamInfo team);

    @Delete
    int deleteTeams(List<TeamInfo> teams);

    @Update
    int updateTeam(TeamInfo team);

    @Query("SELECT * FROM `Team Information`")
    LiveData<List<TeamInfo>> allTeamData();

    @Query("SELECT `Team Name` FROM `Team Information`")
    List<String> allTeamNames();

    @Update
    void changeTeams(List<TeamInfo> newTeams);

    @Query("SELECT * FROM `Team Information`")
    List<TeamInfo> notLiveTeamInfo();

    @Update
    void updateTeams(List<TeamInfo> teams);

    @Query("DELETE FROM `Team Information`")
    int removeEverything();

    @Query("SELECT * FROM `Team Information` WHERE `Team Name` = :name")
    TeamInfo selectedTeams(String name);

    @Query("SELECT COUNT(*) FROM `Team Information`")
    int teamCount();
}
