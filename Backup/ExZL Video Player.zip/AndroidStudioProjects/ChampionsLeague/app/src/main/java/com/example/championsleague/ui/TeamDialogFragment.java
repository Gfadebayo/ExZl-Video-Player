package com.example.championsleague.ui;

import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.championsleague.R;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TeamDialogFragment extends AppCompatDialogFragment {

    public Context mContext;
    private Map<String, List<String>> teamWithLeague;
    public static LayoutInflater inflate;
    Application app;
    private TeamDialogListener mClickListener;

    private TeamDialogFragment(Map<String, List<String>> val) {
        super();
        this.teamWithLeague = val;

    }

    public static TeamDialogFragment dialogInstance(Map<String, List<String>> values){
        return new TeamDialogFragment(values);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragmet_dialog_teams, container, false);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final View parentView = populateDialogView();

        AlertDialog.Builder build = new AlertDialog.Builder(requireActivity());

        build.setView(parentView)

        .setTitle("Existing Teams")
        .setPositiveButton("Select", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mClickListener.positiveDialogButtonClicked(parentView);
            }
        });

        return build.create();
    }

    @Override
    public void setupDialog(@NonNull Dialog dialog, int style) {

        super.setupDialog(dialog, style);

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try{
            mClickListener = (TeamDialogListener) requireActivity();
        }catch(ClassCastException cast){cast.printStackTrace();}
    }


    private View populateDialogView(){
        View retView = null;
        try {
            retView = Executors.newSingleThreadExecutor().submit(new Callable<View>() {
                @Override
                public View call() throws Exception {
                    Set<String> leagues = teamWithLeague.keySet();
                    View parentView = getActivity().getLayoutInflater().inflate(R.layout.fragmet_dialog_teams, null, false);
                    LinearLayout vLinear = parentView.findViewById(R.id.layout_dialog_teams);
                    vLinear.removeAllViews();
//        vLinear.setId(View.generateViewId());
//        ((ViewGroup)vLinear.getParent()).removeView(vLinear);

//        TextView leagueText = vLinear.findViewById(R.id.text_league_header);
//        CheckBox teamBox = vLinear.findViewById(R.id.checkBox_teams);

                    for(String lig : leagues){
                        TextView vi = getActivity().getLayoutInflater().inflate(R.layout.fragmet_dialog_teams, null , false).findViewById(R.id.text_league_header);
                        vi.setText(lig);
                        ((ViewGroup)vi.getParent()).removeView(vi);
                        vLinear.addView(vi);
//            TextView tv = TextView.inflate(requireActivity(), R.layout.fragmet_dialog_teams,(ViewGroup) requireActivity()
//                    .findViewById(R.id.layout_dialog_teams)).findViewById(R.id.text_league_header);
//            tv.setText(lig);
                        for(int i = 0; i < teamWithLeague.get(lig).size(); i++){
                            CheckBox box = getActivity().getLayoutInflater().inflate(R.layout.fragmet_dialog_teams, null, false).findViewById(R.id.checkBox_teams);
//                CheckBox box = CheckBox.inflate(requireActivity(), R.layout.fragmet_dialog_teams,(ViewGroup) vLinear).findViewById(R.id.checkBox_teams);
                            box.setText(teamWithLeague.get(lig).get(i));
                            ((ViewGroup)box.getParent()).removeView(box);
                            vLinear.addView(box);
                        }
                    }

                    return parentView;
                }
            }).get();
        }catch(Exception e){e.printStackTrace();}
       return retView;
   }

   public interface TeamDialogListener {

        void positiveDialogButtonClicked(View dialogView);
   }
}
