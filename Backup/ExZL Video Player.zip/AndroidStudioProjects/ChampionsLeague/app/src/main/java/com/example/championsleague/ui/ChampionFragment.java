package com.example.championsleague.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.championsleague.R;
import com.example.championsleague.models.TeamInfo;
import com.example.championsleague.ui.standing.StandingViewModel;

import java.util.List;

public class ChampionFragment extends Fragment {

    private StandingViewModel viewModel;
    private int position = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_champion, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        viewModel = new ViewModelProvider(requireActivity(), ViewModelProvider.AndroidViewModelFactory
                .getInstance(getActivity().getApplication())).get(StandingViewModel.class);

        view.findViewById(R.id.button_next_champion).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ConstraintLayout)getView().findViewById(R.id.layout_champion)).removeAllViews();

                position++;
                createChampionCards();
            }
        });


//        view.findViewById(R.id.button_prev_champion).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ((ConstraintLayout)getView().findViewById(R.id.layout_champion)).removeAllViews();
//
//                position--;
//                createChampionCards();
//            }
//        });
    }

    public void createChampionCards(){

        List<TeamInfo> teamInfos = viewModel.getTeamInformation(requireActivity()).getValue();

            CardView viewCards = (CardView) getLayoutInflater().inflate(R.layout.fragment_champion,
                    (ViewGroup) getView().findViewById(R.id.card_view_fixture), true);

            ((TextView)viewCards.findViewById(R.id.winning_team_name)).setText(teamInfos.get(position).getTeamName());

            ((TextView) viewCards.findViewById(R.id.winning_team_point)).setText(teamInfos.get(position).getCurrentPoint());

            ((TextView) viewCards.findViewById(R.id.winning_team_wins)).setText(teamInfos.get(position).getWins());

            ((TextView) viewCards.findViewById(R.id.winning_team_loss)).setText(teamInfos.get(position).getLosses());

            ((TextView) viewCards.findViewById(R.id.winning_team_draws)).setText(teamInfos.get(position).getDraws());
        }
}
