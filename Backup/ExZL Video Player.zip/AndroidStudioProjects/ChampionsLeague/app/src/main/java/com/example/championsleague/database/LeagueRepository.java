package com.example.championsleague.database;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.Room;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.championsleague.models.FixtureInfo;
import com.example.championsleague.models.LeagueInfo;
import com.example.championsleague.models.TeamInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class LeagueRepository {

    private final String DB_NAME = "db_league";
    private LeagueDatabase db;
    private static LeagueRepository leagueInstance;
    private TeamDao teamDao;
    private FixtureDao fixtureDao;
    private ExecutorService threadExecutor;
//    private Executor executor;

    private LeagueRepository(Application app) {

        db = Room.databaseBuilder(app.getApplicationContext(), LeagueDatabase.class, DB_NAME)
                .addMigrations(MIGRATE_2_8, MIGRATE_8_14, MIGRATE_14_17, MIGRATE_17_25)
                .build();

//        mAct = activity;
        teamDao = db.getTeamDao();
        fixtureDao = db.getFixtureDao();

        threadExecutor = Executors.newSingleThreadExecutor();
    }

    public static LeagueRepository getInstance(Application app) {

        if (leagueInstance == null) {
            leagueInstance = new LeagueRepository(app);
        }

        return leagueInstance;
    }

    public void insertTeams(final List<TeamInfo> teams) {
        threadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                teamDao.insertTeam(teams);
            }
        });
    }

    public void updateTeams(List<TeamInfo> te) {
        teamDao.updateTeams(te);
    }

    public LiveData<List<TeamInfo>> getCurrentStanding() {
        LiveData<List<TeamInfo>> res = null;
        try {
            res =
                    threadExecutor.submit(new Callable<LiveData<List<TeamInfo>>>() {
                        @Override
                        public LiveData<List<TeamInfo>> call() throws Exception {
                            return teamDao.allTeamData();
                        }
                    }).get();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return res;
    }

    public int teamCount() {
        int resu = 0;

        Future<Integer> res = threadExecutor.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                return teamDao.teamCount();
            }
        });
        try {
            resu = res.get();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resu;
    }

    public List<String> teamNames() {
        List<String> names = null;

        Future<List<String>> res = threadExecutor.submit(new Callable<List<String>>() {
            @Override
            public List<String> call() throws Exception {
                return teamDao.allTeamNames();
            }
        });
        try {
            names = res.get();
        } catch (Exception e) {
            e.printStackTrace();
        }


        return names;
    }

    public List<FixtureInfo> allFixturesLiveNot(final int leg, List<String> teams) {
        final List<String> v2;
        if (teams == null) {
            v2 = teamNames();
        } else {
            v2 = teams;
        }
        List<FixtureInfo> infoResult = null;

        Future<List<FixtureInfo>> res = threadExecutor.submit(new Callable<List<FixtureInfo>>() {
            @Override
            public List<FixtureInfo> call() throws Exception {

                List<FixtureInfo> gottenFixtures = new ArrayList<>();

                for (int i = 0; i < v2.size(); i++) {
                    if (leg == 0) {
                        gottenFixtures.addAll(fixtureDao.allFixturesNoLeg(v2.get(i)));
                    } else gottenFixtures.addAll(fixtureDao.allFixturesNotLive(leg, v2.get(i)));
                }
                List<FixtureInfo> sortedFixtures = LeagueInfo.getInstance().removeDuplicates(gottenFixtures);
                Collections.sort(sortedFixtures);

                return sortedFixtures;
            }
        });
        try {
            infoResult = res.get();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return infoResult;
    }

    public List<TeamInfo> notLiveTeamInfo() {
        List<TeamInfo> teems = new ArrayList<>();
        try {
            teems.addAll(
                    threadExecutor.submit(new Callable<List<TeamInfo>>() {
                        @Override
                        public List<TeamInfo> call() throws Exception {
                            return teamDao.notLiveTeamInfo();
                        }
                    }).get());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return teems;
    }

    public int deleteTeams(List<TeamInfo> no) {

        return teamDao.deleteTeams(no);
    }

    public void insertFixtures(final List<FixtureInfo> sendFixtures) {
        Collections.sort(sendFixtures);
        threadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                fixtureDao.insertFixtures(sendFixtures);
            }
        });
    }

    public void deleteFixtures(List<FixtureInfo> fix) {

        fixtureDao.deleteFixtures(fix);
    }

    public LiveData<List<FixtureInfo>> displayAllFixtures(final int leg) {
        LiveData<List<FixtureInfo>> returnedFixtures = null;
        try {
            returnedFixtures = threadExecutor.submit(new Callable<LiveData<List<FixtureInfo>>>() {
                @Override
                public LiveData<List<FixtureInfo>> call() throws Exception {
                    if (leg == 1 || leg == 2) {
                        return fixtureDao.allFixturesByLeg(leg);
                    } else {
                        return fixtureDao.allFixtures();
                    }
                }
            }).get();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return returnedFixtures;
    }

    public void nukeEverything() {
        threadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                teamDao.removeEverything();
            }
        });
    }

    public void nukeAllFixtures() {
        threadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                fixtureDao.deleteEverything();
            }
        });
    }

    public List<TeamInfo> teamLive(final FixtureInfo twoTeams) {
        List<TeamInfo> returnedTeams = null;
        try {
            returnedTeams = threadExecutor.submit(new Callable<List<TeamInfo>>() {
                @Override
                public List<TeamInfo> call() throws Exception {
                    List<TeamInfo> ok = new LinkedList<>();

                    ok.add(0, teamDao.selectedTeams(twoTeams.getHomeTeam()));
                    ok.add(1, teamDao.selectedTeams(twoTeams.getAwayTeam()));
                    return ok;
                }
            }).get();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return returnedTeams;
    }

    public FixtureInfo submittedFixtures(final int fixPosition) {
        FixtureInfo returnedFixture = null;
        try {
            returnedFixture = threadExecutor.submit(new Callable<FixtureInfo>() {
                @Override
                public FixtureInfo call() throws Exception {
                    return fixtureDao.newFixtures(fixPosition);
                }
            }).get();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnedFixture;
    }

    public void updateTeam(final List<TeamInfo> updatedTeams) {
        threadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                int ifUpdated = 0;

                Collections.sort(updatedTeams);
                for (TeamInfo info : updatedTeams) {
                    info.setCurrentPosition(updatedTeams.indexOf(info) + 1);
                    ifUpdated += teamDao.updateTeam(info);
                }
            }
        });
    }

    public void updateFixtures(final int homeScore, final int awayScore, final int fixtureNo) {
        threadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                fixtureDao.updateSelectedFixture(homeScore, awayScore, fixtureNo);
            }
        });
    }

    public List<Integer> fixtureNos() {
        List<Integer> nos = null;
        try {
            nos = threadExecutor.submit(new Callable<List<Integer>>() {
                @Override
                public List<Integer> call() throws Exception {
                    return fixtureDao.allFixtureNos();
                }
            }).get();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return nos;
    }

    static Migration MIGRATE_2_8 = new Migration(2, 8) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {

            database.execSQL("CREATE TABLE fixinfos(`Home Team` TEXT, `Away Team` TEXT, `Home Score` INTEGER NOT NULL," +
                    " `Away Score` INTEGER NOT NULL, `Fixture no` INTEGER NOT NULL PRIMARY KEY)");

            database.execSQL("INSERT INTO fixinfos(`Home Team`, `Away Team`, `Home Score`, `Away Score`) SELECT `Home Team`, `Away Team`, `Home Score`, `Away Score` FROM `Fixtures`");

            database.execSQL("DROP TABLE `Fixtures`");

            database.execSQL("ALTER TABLE fixinfos RENAME TO `Fixtures`");

            database.execSQL("CREATE TABLE infos(`Team Name` TEXT NOT NULL PRIMARY KEY DEFAULT 0, `Points` INTEGER NOT NULL, `Position` INTEGER NOT NULL, `Goal Difference` INTEGER NOT NULL, id INTEGER NOT NULL)");

            database.execSQL("INSERT INTO infos(`Team Name`, Points, Position, `Goal Difference`, id) SELECT `Team Name`, Points, Position, `Goal Difference`, id FROM `Team Information`");

            database.execSQL("DROP TABLE `Team Information`");

            database.execSQL("ALTER TABLE infos RENAME TO `Team Information`");

//            database.execSQL("ALTER TABLE `Team Information` RENAME  COLUMN id TO Played");


        }
    };

    static Migration MIGRATE_8_14 = new Migration(8, 14) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {

            database.execSQL("CREATE TABLE fixinfos(`Home Team` TEXT, `Away Team` TEXT," +
                    " `Home Score` INTEGER NOT NULL, `Away Score` INTEGER NOT NULL, `Fixture no` INTEGER NOT NULL PRIMARY KEY, `Leg` INTEGER NOT NULL DEFAULT 0)");

            database.execSQL("INSERT INTO fixinfos(`Home Team`, `Away Team`, `Home Score`, `Away Score`, `Fixture no`) " +
                    "SELECT `Home Team`, `Away Team`, `Home Score`, `Away Score`, `Fixture no`FROM `Fixtures`");

            database.execSQL("DROP TABLE `Fixtures`");

            database.execSQL("ALTER TABLE fixinfos RENAME TO `Fixtures`");


            database.execSQL("CREATE TABLE infos(`Team Name` TEXT NOT NULL PRIMARY KEY, `Points` INTEGER NOT NULL," +
                    " `Position` INTEGER NOT NULL, `Goal Difference` INTEGER NOT NULL, id INTEGER NOT NULL," +
                    " Wins INTEGER NOT NULL DEFAULT 0, Losses INTEGER NOT NULL DEFAULT 0, Draws INTEGER NOT NULL DEFAULT 0)");

            database.execSQL("INSERT INTO infos(`Team Name`, Points, Position, `Goal Difference`, id)" +
                    " SELECT `Team Name`, Points, Position, `Goal Difference`, id FROM `Team Information`");

            database.execSQL("DROP TABLE `Team Information`");

            database.execSQL("ALTER TABLE infos RENAME TO `Team Information`");


        }
    };

    static Migration MIGRATE_14_17 = new Migration(14, 17) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE `Team Information` ADD COLUMN Logo TEXT");
            database.execSQL("ALTER TABLE `Fixtures` ADD COLUMN homeLogo TEXT");
            database.execSQL("ALTER TABLE Fixtures ADD COLUMN awayLogo TEXT");
        }
    };

    static Migration MIGRATE_17_25 = new Migration(17, 25) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE fixinfos(`Home Team` TEXT, `Away Team` TEXT," +
                    " `Home Score` INTEGER NOT NULL, `Away Score` INTEGER NOT NULL," +
                    " `Fixture no` INTEGER NOT NULL PRIMARY KEY, `Leg` INTEGER NOT NULL DEFAULT 0)" +
                    " ");

            database.execSQL("INSERT INTO fixinfos(`Home Team`, `Away Team`, `Home Score`, `Away Score`, `Fixture no`) " +
                    "SELECT `Home Team`, `Away Team`, `Home Score`, `Away Score`, `Fixture no`FROM `Fixtures`");

            database.execSQL("DROP TABLE `Fixtures`");

            database.execSQL("ALTER TABLE fixinfos RENAME TO `Fixtures`");

            database.execSQL("CREATE TABLE infos(`Team Name` TEXT NOT NULL PRIMARY KEY, `Points` INTEGER NOT NULL," +
                    " `Position` INTEGER NOT NULL, `Goal Difference` INTEGER NOT NULL, id INTEGER NOT NULL," +
                    " Wins INTEGER NOT NULL DEFAULT 0, Losses INTEGER NOT NULL DEFAULT 0, Draws INTEGER NOT NULL DEFAULT 0, " +
                    " `Logo` TEXT)");

            database.execSQL("INSERT INTO infos(`Team Name`, Points, Position, `Goal Difference`, id, Wins, Losses, Draws)" +
                    " SELECT `Team Name`, Points, Position, `Goal Difference`, id, Wins, Losses, Draws FROM `Team Information`");

            database.execSQL("DROP TABLE `Team Information`");

            database.execSQL("ALTER TABLE infos RENAME TO `Team Information`");        }
    };
}