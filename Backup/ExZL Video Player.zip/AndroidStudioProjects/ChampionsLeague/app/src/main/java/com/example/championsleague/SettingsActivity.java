package com.example.championsleague;

import android.content.ContentProvider;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriMatcher;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Picture;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.text.InputType;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.preference.EditTextPreference;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        Toolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings, new SettingsFragment())
                .commit();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }


    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);

            EditTextPreference lengthPref = findPreference("team_length");
            lengthPref.setDefaultValue(3);
            lengthPref.setOnBindEditTextListener(new EditTextPreference.OnBindEditTextListener() {
                @Override
                public void onBindEditText(@NonNull EditText editText) {
                    editText.setInputType(InputType.TYPE_CLASS_NUMBER);
                }
            });

            ListPreference listPref = findPreference("fav_pos");
            listPref.setSummaryProvider(new Preference.SummaryProvider() {
                @Override
                public CharSequence provideSummary(Preference preference) {
                    return((ListPreference) preference).getValue();
                }
            });
        }

        public SettingsFragment getInstance(){
            return new SettingsFragment();
        }

        private void getFavouriteLogo(){
            Intent fileIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fileIntent.setType("image/*");
            fileIntent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(fileIntent, 1);
        }

        @Override
        public boolean onPreferenceTreeClick(Preference preference) {

            if(preference.getKey().equals("fav_team_logo")){
                getFavouriteLogo();
            }
            return super.onPreferenceTreeClick(preference);
        }
        @Override
        public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

            if(data.getData() == null && requestCode == 1) return;

            final Uri dataUri = data.getData();
            Preference logo = findPreference("fav_team_logo");
            SharedPreferences.Editor favTeamLogo = logo.getSharedPreferences().edit();
            favTeamLogo.putString("fav_team_logo", data.getDataString()).apply();

            logo.setSummaryProvider(new Preference.SummaryProvider() {
                @Override
                public CharSequence provideSummary(Preference preference) {
                    return dataUri.buildUpon().toString();
                }
            });

        }
    }
}