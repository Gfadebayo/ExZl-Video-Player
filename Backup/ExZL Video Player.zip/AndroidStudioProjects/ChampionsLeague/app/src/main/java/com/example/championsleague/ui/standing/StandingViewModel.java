package com.example.championsleague.ui.standing;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

import com.example.championsleague.database.FixtureDao;
import com.example.championsleague.database.LeagueRepository;
import com.example.championsleague.models.FixtureInfo;
import com.example.championsleague.models.LeagueInfo;
import com.example.championsleague.models.TeamInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StandingViewModel extends AndroidViewModel {

    private MutableLiveData<List<TeamInfo>> teamInformation;
    private LeagueRepository leagueRepo;


    public StandingViewModel(@NonNull Application application) {
        super(application);
        leagueRepo = LeagueRepository.getInstance(application);
    }


    public LiveData<List<TeamInfo>> getTeamInformation(LifecycleOwner o){

        leagueRepo.getCurrentStanding().observe(o, new Observer<List<TeamInfo>>() {
            @Override
            public void onChanged(List<TeamInfo> teamInfos) {
                Collections.sort(teamInfos);
                teamInfos = LeagueInfo.getInstance().incrementFixtureOrTeam(teamInfos, null);
            }
        });
        return leagueRepo.getCurrentStanding();
    }

    public List<FixtureInfo> allFixtures(){

        return leagueRepo.allFixturesLiveNot(0, null);
    }

    public int teamCount(){
        return leagueRepo.teamCount();
    }
}
