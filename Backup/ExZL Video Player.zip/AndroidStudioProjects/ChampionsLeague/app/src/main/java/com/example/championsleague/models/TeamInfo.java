package com.example.championsleague.models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.sql.Blob;
import java.text.CollationElementIterator;
import java.text.Collator;
import java.util.Comparator;
import java.util.Locale;

@Entity(tableName = "Team Information")
public class TeamInfo implements Comparable {

    @ColumnInfo(name = "Team Name")
    @NonNull
    @PrimaryKey
    private String teamName;

   // @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "Points")
    private int currentPoint;

    @ColumnInfo(name = "Position")
    private int currentPosition;

    @ColumnInfo(name = "Goal Difference")
    private int currentGoalDifference;

    @NonNull
    private int Wins;

    @NonNull
    private int Losses;

    @NonNull
    private int Draws;

    @Ignore
    private Bitmap Logo;

    @ColumnInfo(name = "Logo")
    private String logoUri;

    public TeamInfo(){}

    public String getLogoUri() {
        return logoUri;
    }

    public void setLogoUri(String logoUri) {
        this.logoUri = logoUri;
    }

    @Ignore
    public TeamInfo(String name, String logoPath){

        teamName = name;
        currentGoalDifference = 0;
        currentPosition = 0;
        currentPoint = 0;
        id = 0;
        Wins = 0;
        Losses = 0;
        Draws = 0;
        logoUri = logoPath;
        getImage();
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String name) {
        teamName = name;
    }

    public int getCurrentPoint() {
        return currentPoint;
    }

    public void setCurrentPoint(int point) {
        currentPoint = point;
    }

    public int getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition(int position) {
        currentPosition = position;
    }

    public int getCurrentGoalDifference() {
        return currentGoalDifference;
    }

    public void setCurrentGoalDifference(int goalDifference) {
        currentGoalDifference = goalDifference;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @NonNull
    @Override
    public String toString() {
        return teamName;
    }

    @Override
    public int compareTo(Object o) {
        TeamInfo team = (TeamInfo) o;
        Collator englishCollator = Collator.getInstance(Locale.ENGLISH);
        int comp = 0;


        if(this.currentPoint != team.currentPoint){

            comp = -Integer.compare(this.currentPoint, team.currentPoint);
        }else if(this.currentGoalDifference != team.currentGoalDifference){

            comp = -Integer.compare(this.currentGoalDifference, team.currentGoalDifference);
        }else{
            comp = englishCollator.compare(this.teamName, team.teamName);
        }

        return comp;
    }

    public void incrementPoint(int amount){

        currentPoint+=amount;
    }

    public void incrementGoalDiff(int amount){

        currentGoalDifference+=amount;
    }

    public int getWins() {
        return Wins;
    }

    public void setWins(int wins) {
        this.Wins = wins;
    }

    public int getLosses() {
        return Losses;
    }

    public void setLosses(int losses) {
        this.Losses = losses;
    }

    public int getDraws() {
        return Draws;
    }

    public void setDraws(int draws) {
        this.Draws = draws;
    }

    public Bitmap getLogo(){return Logo;}

    public void setLogo(Bitmap newLogo){
        Logo = newLogo;
    }

    public Bitmap getImage(){
        try {
           InputStream is = new FileInputStream(logoUri);
           File f = new File(logoUri);
           BitmapFactory.Options op = new BitmapFactory.Options();
           op.inSampleSize = 4;
           Logo = BitmapFactory.decodeFile(logoUri, op);
        }catch(Exception e){e.printStackTrace();}

        return Logo;
    }
}
