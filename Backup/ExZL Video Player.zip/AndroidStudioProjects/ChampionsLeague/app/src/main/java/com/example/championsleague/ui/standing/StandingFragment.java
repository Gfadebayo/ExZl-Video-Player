package com.example.championsleague.ui.standing;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.championsleague.R;
import com.example.championsleague.database.LeagueRepository;
import com.example.championsleague.models.FixtureInfo;
import com.example.championsleague.models.TeamInfo;
import com.example.championsleague.ui.ChampionFragment;

import java.util.List;

public class StandingFragment extends Fragment {

    private LeagueRepository leagueRepository;
    private StandingViewModel viewModel;
    private TableLayout tableLayout;
    private View inflatedTable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        inflatedTable = getLayoutInflater().inflate(R.layout.table_row_values, null, false);

        View view = inflater.inflate(R.layout.fragment_standing, container, false);
        tableLayout = view.findViewById(R.id.table_outer);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity(), ViewModelProvider.AndroidViewModelFactory.
                getInstance(getActivity().getApplication())).get(StandingViewModel.class);

//        getStanding(viewModel.teamCount());

        viewModel.getTeamInformation(requireActivity()).observe(requireActivity(), new Observer<List<TeamInfo>>() {
            @Override
            public void onChanged(List<TeamInfo> teamInfos) {
                getStanding(teamInfos);
            }
        });

//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                List<TeamInfo> sumAllFixtures = viewModel.getTeamInformation(getActivity()).getValue();
//                int fixtureSum = viewModel.allFixtures().size();
//                int summ = 0;
//                for(TeamInfo o : sumAllFixtures){
//
//                    summ+=o.getId();
//                }
//
//                if(summ >= 12){
//                    getView().findViewById(R.id.button_close_up).setVisibility(View.VISIBLE);
//                }
//            }
//        });

        view.findViewById(R.id.button_close_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .detach(StandingFragment.this)
                        .replace(R.id.nav_host_fragment, new ChampionFragment())
                        .commit();
            }
        });
    }

    private void getStanding(List<TeamInfo> fo){

        if(tableLayout.getChildCount() >= (2 * fo.size()) + 3){
            return;
        }

        for(int i = 0; i < fo.size(); i++){

//            TableRow leagueTable = (TableRow) getLayoutInflater().inflate(R.layout.table_row_values,
//                    (ViewGroup) getView().findViewById(R.id.table_actual_information), false);

            TableRow leagueTable = getLayoutInflater()
                    .inflate((R.layout.table_row_values), (ViewGroup) inflatedTable, false)
                    .findViewById(R.id.table_actual_informations);

            TableRow leagueLine = getLayoutInflater()
                    .inflate(R.layout.table_row_values, (ViewGroup) inflatedTable, false)
                    .findViewById(R.id.straignt_line_for_row);


            TeamInfo info = fo.get(i);
            TextView text1 = leagueTable.findViewById(R.id.text_pos1);
            text1.setText(Integer.toString(info.getCurrentPosition()));
            TextView text2 = leagueTable.findViewById(R.id.text_name1);
            text2.setText(info.getTeamName());
            TextView text3 = leagueTable.findViewById(R.id.text_played1);
            text3.setText(Integer.toString(info.getId()));
            TextView text4 = leagueTable.findViewById(R.id.text_goald1);
            text4.setText(Integer.toString(info.getCurrentGoalDifference()));
            TextView text5 = leagueTable.findViewById(R.id.text_point1);
            text5.setText(Integer.toString(info.getCurrentPoint()));

            ((ViewGroup)leagueTable.getParent()).removeView(leagueTable);
            ((ViewGroup)leagueLine.getParent()).removeView(leagueLine);

            if(i == 0) leagueTable.setBackgroundColor(getContext().getColor(R.color.first_position));
            else if(i == 1) leagueTable.setBackgroundColor(getContext().getColor(R.color.second_position));
            else if(i == 2) leagueTable.setBackgroundColor(getContext().getColor(R.color.third_position));

            tableLayout.addView(leagueTable);
            tableLayout.addView(leagueLine);
//            tableLayout.addView(leagueTable.findViewById(R.id.table_straight_line));
        }
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {

        inflater.inflate(R.menu.fragment_menu, menu);

        super.onCreateOptionsMenu(menu, inflater);
    }

    public void allFixturesCompleted(){

        //replace this method once youre able to count the number of records in a table
        List<FixtureInfo> allFixtures = viewModel.allFixtures();
        int allFixtureSum = allFixtures.size();

        List<TeamInfo> allTeams = viewModel.getTeamInformation(requireActivity()).getValue();
        int sumOfPlayedFixtures = 0;
        try {
            for (TeamInfo fo : allTeams) {
                sumOfPlayedFixtures+=fo.getId();
            }
        }catch(NullPointerException nulll){nulll.printStackTrace();}

        if(allFixtureSum == sumOfPlayedFixtures){
            getView().findViewById(R.id.button_close_up).setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void onResume() {

        allFixturesCompleted();
        super.onResume();
    }
}
