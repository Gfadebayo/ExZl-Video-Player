package com.example.championsleague.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Room;
import androidx.room.Update;

import com.example.championsleague.models.FixtureInfo;

import java.util.List;

@Dao
public interface FixtureDao {

    @Insert
    void insertFixture(FixtureInfo fixture);

    @Update()
    void updateFixture(FixtureInfo fixture);

    @Delete
    void deleteFixture(FixtureInfo fixture);

    @Query("SELECT * FROM Fixtures")
    LiveData<List<FixtureInfo>> allFixtures();

    @Query("SELECT * FROM Fixtures WHERE Leg= :leg")
    LiveData<List<FixtureInfo>> allFixturesByLeg(int leg);

    @Delete
    void deleteFixtures(List<FixtureInfo> allFixtures);

    @Insert
    void insertFixtures(List<FixtureInfo> fixtures);

    @Query("DELETE FROM Fixtures")
    int deleteEverything();

    @Query("SELECT * FROM Fixtures WHERE `Fixture no` = :number")
    FixtureInfo newFixtures(int number);

    @Query("UPDATE Fixtures SET `Home Score`=:homeScore, `Away Score`=:awayScore WHERE `Fixture no`=:fixtureNo")
    void updateSelectedFixture(int homeScore, int awayScore, int fixtureNo);

    @Query("SELECT * FROM Fixtures WHERE Leg= :leg AND (`Home Team`= :teams OR `Away Team`= :teams) AND `Home Score`= -1")
    List<FixtureInfo> allFixturesNotLive(int leg,String teams);

    @Query("SELECT * FROM Fixtures WHERE (`Home Team`= :teams OR `Away Team`= :teams) AND `Home Score`= -1")
    List<FixtureInfo> allFixturesNoLeg(String teams);

    @Query("SELECT `Fixture no` FROM Fixtures")
    List<Integer> allFixtureNos();

}
