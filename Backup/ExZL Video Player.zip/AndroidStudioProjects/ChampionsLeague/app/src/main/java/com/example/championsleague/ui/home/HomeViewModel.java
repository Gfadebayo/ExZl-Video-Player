package com.example.championsleague.ui.home;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.championsleague.FixtureRecyclerAdapter;
import com.example.championsleague.database.LeagueRepository;
import com.example.championsleague.models.FixtureInfo;
import com.example.championsleague.models.League;
import com.example.championsleague.models.TeamInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class HomeViewModel extends AndroidViewModel{

    private LeagueRepository leagueRepo;
    private MutableLiveData<Integer> recyclerId;
    public int mLeg;
    public List<String> mTrimTeams;
    public MutableLiveData<List<Integer>> legStates;
    public MutableLiveData<List<FixtureInfo>> deletedFixtures;
    public List<Integer> submittedFixtureNo;
    private Map<Integer, int[]> predictedScores;

    public HomeViewModel(@NonNull Application application) {
        super(application);
        leagueRepo = LeagueRepository.getInstance(application);
        mLeg = 0;
        if(mTrimTeams == null) mTrimTeams = getTeamNames();
        if(predictedScores == null) predictedScores = new HashMap<>();
    }

    public List<FixtureInfo> getFixtures(){
        int index = 0;
        int count = 0;
        List<FixtureInfo> fixtureInfos = leagueRepo.allFixturesLiveNot(mLeg, mTrimTeams);
        List<TeamInfo> teamInfos = leagueRepo.notLiveTeamInfo();
        for (FixtureInfo f :
                fixtureInfos) {

            for(TeamInfo t : teamInfos) {
                if (t.getTeamName().equals(f.getHomeTeam())) {
                    f.setHomeLogo(t.getImage());
                }

                if (t.getTeamName().equals(f.getAwayTeam())) {
                    f.setAwayLogo(t.getImage());
                }
            }

            count++;
        }
        return fixtureInfos;
    }


    public List<TeamInfo> getSelectedTeams(int fixturePosition){

        return leagueRepo.teamLive(leagueRepo.submittedFixtures(fixturePosition));
    }

    public FixtureInfo fixture(int fixturePosition){
        return leagueRepo.submittedFixtures(fixturePosition);
    }

    public void updateTeamDb(List<TeamInfo> go){

        leagueRepo.updateTeam(go);
    }

    public void updateFixtureTable(int homeScore, int awayScore, int fixtureNo){
        leagueRepo.updateFixtures(homeScore, awayScore, fixtureNo);
    }

    public LiveData<Integer> getRecyclerId(){

        if(recyclerId == null){
            recyclerId = new MutableLiveData<>();
        }

        return  recyclerId;
    }

    public List<String> getTeamNames(){

        return leagueRepo.teamNames();
    }

    public LiveData<List<Integer>> getLegStates(){
        if(legStates == null){
            legStates = new MutableLiveData<>();
            legStates.postValue(new LinkedList<>(Collections.nCopies(2, 0)));
        }
        return legStates;
    }

    public LiveData<List<FixtureInfo>> getDeletedFixtures(){
        if(deletedFixtures == null){
            deletedFixtures = new MutableLiveData<>();
            deletedFixtures.postValue(new LinkedList<FixtureInfo>());
        }

        return deletedFixtures;
    }
    public List<Integer> getSubmittedFixtureNo(){

        return submittedFixtureNo;
    }

    public void setSubmittedFixtureNo(boolean isEval, int fixtureNo){

        if(submittedFixtureNo == null){
            submittedFixtureNo = new ArrayList<Integer>();
        }

        if(!isEval) submittedFixtureNo.remove((Object) fixtureNo);
        else submittedFixtureNo.add(fixtureNo);
    }

    public Map<Integer, int[]> getPredictedScores(){
        return predictedScores;
    }
}
